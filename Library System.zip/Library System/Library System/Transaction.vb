﻿Imports System.Data.SqlClient

Public Class frmTransaction
    Private Structure BorrowBookData
        Dim strBookID As String
        Dim strBookTitle As String
        Dim strStudID As String
        Dim strStudName As String
        Dim intQtyBorrow As Integer
        Dim returnDate As Date
    End Structure

    Private Structure ReturnBookData
        Dim strBookID As String
        Dim strBookTitle As String
        Dim strStudID As String
        Dim strStudName As String
        Dim returnDate As Date
        Dim intQtyReturn As Integer
        Dim intQtyBorrow As Integer
    End Structure

    Private Structure FinePaymentData
        Dim strStudID As String
        Dim strBookID As String
        Dim strReason As String
        Dim returnDate As Date
        Dim dblCharge As Double
        Dim intQty As Integer
    End Structure

    Dim borrow As BorrowBookData
    Dim returnBook As ReturnBookData
    Dim finePay As FinePaymentData
    Dim currentDate As Date = Date.Now
    Dim selectedRowIndex As Integer
    Dim intConfirmCharge As Integer

    Private confirmBook, confirmStud As Integer

    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        End
    End Sub

    Private Sub btnBorrow_Click(sender As Object, e As EventArgs) Handles btnBorrow.Click
        pnlLeftBorrow.Visible = True
        pnlLeftReturn.Visible = False
        pnlLeftFine.Visible = False

        panelBorrow.Visible = True
        panelReturn.Visible = False
        panelFine.Visible = False
    End Sub

    Private Sub btnReturn_Click(sender As Object, e As EventArgs) Handles btnReturn.Click
        pnlLeftBorrow.Visible = False
        pnlLeftReturn.Visible = True
        pnlLeftFine.Visible = False

        panelBorrow.Visible = False
        panelReturn.Visible = True
        panelFine.Visible = False

        chkAccident.Checked = False
        rabDamage.Checked = False
        rabLost.Checked = False

        Dim connection As New SqlConnection
        connection.ConnectionString = "Data Source =  (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\Sim Ka Yee\Documents\Tarc\Diploma\Year 2 Sem 2\Windows Application Programming\Library System\Library System\TestingDatabase1.mdf; Integrated Security = true"
        Dim command As New SqlCommand("Select * From borrowed_book", connection)
        connection.Open()
        Dim adapter As New SqlDataAdapter(command)
        Dim table As New DataTable
        adapter.Fill(table)
        viewBorrowedBook.DataSource = table
        connection.Close()
    End Sub

    Private Sub btnFine_Click(sender As Object, e As EventArgs) Handles btnFine.Click
        pnlLeftBorrow.Visible = False
        pnlLeftReturn.Visible = False
        pnlLeftFine.Visible = True

        panelBorrow.Visible = False
        panelReturn.Visible = False
        panelFine.Visible = True

        lblOverdueDay.Text = ""
        lblFine.Text = ""
        txtCash.Text = ""
        lblChange.Text = ""

        Dim connection As New SqlConnection
        connection.ConnectionString = "Data Source =  (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\Sim Ka Yee\Documents\Tarc\Diploma\Year 2 Sem 2\Windows Application Programming\Library System\Library System\TestingDatabase1.mdf; Integrated Security = true"
        Dim command As New SqlCommand("Select * From Fine_Payment
                                       Where PayStatus = 'Unpay'", connection)
        Dim adapter As New SqlDataAdapter(command)
        Dim table As New DataTable
        adapter.Fill(table)

        viewFine.DataSource = table
    End Sub

    Private Sub frmTransaction_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        pnlLeftBorrow.Visible = True
        pnlLeftReturn.Visible = False
        pnlLeftFine.Visible = False
        panelBorrow.Visible = True
        panelReturn.Visible = False
        panelFine.Visible = False

        txtBookID.Focus()
    End Sub

    Private Sub SearchBook(strBookID As String)
        confirmBook = 0
        cmbQtyBorrow.SelectedIndex = -1
        cmbQtyBorrow.Items.Clear()

        Dim connection As New SqlConnection
        connection.ConnectionString = "Data Source =  (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\Sim Ka Yee\Documents\Tarc\Diploma\Year 2 Sem 2\Windows Application Programming\Library System\Library System\TestingDatabase1.mdf; Integrated Security = true"
        Dim command As New SqlCommand("Select * From Book
                                       Where BookID = @bookID", connection)
        command.Parameters.AddWithValue("@bookID", strBookID)

        Dim adapter As New SqlDataAdapter(command)
        Dim table As New DataTable
        adapter.Fill(table)

        If table.Rows.Count() > 0 Then
            lblTitle.Text = table.Rows(0)(1).ToString()
            lblQuantity.Text = table.Rows(0)(5).ToString()
            confirmBook += 1

            Dim quantityAvailable As Integer = lblQuantity.Text
            If quantityAvailable = 0 Then
                MessageBox.Show("There are no quantity available of the book in the library.", "TARC Library", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                lblTitle.Text = ""
                lblQuantity.Text = ""
                txtBookID.SelectAll()
            Else
                For i = 1 To quantityAvailable Step 1
                    cmbQtyBorrow.Items.Add(i)
                Next
            End If
        Else
            MessageBox.Show("No Book Data Found.", "TARC Library", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtBookID.Text = ""
            lblTitle.Text = ""
            lblQuantity.Text = ""
            txtBookID.Focus()
        End If
    End Sub

    Private Sub btnCheckBook_Click(sender As Object, e As EventArgs) Handles btnCheckBook.Click
        borrow.strBookID = txtBookID.Text
        SearchBook(borrow.strBookID)
        borrow.strBookTitle = lblTitle.Text
    End Sub

    Private Sub SearchStudent(strStudID As String)
        confirmStud = 0
        Dim connection As New SqlConnection
        connection.ConnectionString = "Data Source =  (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\Sim Ka Yee\Documents\Tarc\Diploma\Year 2 Sem 2\Windows Application Programming\Library System\Library System\TestingDatabase1.mdf; Integrated Security = true"
        Dim command As New SqlCommand("Select * From Student
                                       Where StudentID = @studentID", connection)
        command.Parameters.AddWithValue("@studentID", strStudID)
        Dim adapter As New SqlDataAdapter(command)
        Dim table As New DataTable
        adapter.Fill(table)

        Dim command1 As New SqlCommand("Select * From BlackList Where StudentID = @studentID", connection)
        command1.Parameters.AddWithValue("@studentID", strStudID)
        Dim adapter1 As New SqlDataAdapter(command1)
        Dim table1 As New DataTable
        adapter1.Fill(table1)

        If table1.Rows.Count() = 0 Then
            If table.Rows.Count() > 0 Then
                lblStudName.Text = table.Rows(0)(1).ToString()
                lblIC.Text = table.Rows(0)(3).ToString()

                confirmStud += 1
            Else
                MessageBox.Show("No Student Data Found.", "TARC Library", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                txtStudID.Text = ""
                lblStudName.Text = ""
                lblIC.Text = ""
                txtStudID.Focus()
            End If
        Else
            MessageBox.Show("The student has been blacklisted.", "TARC Library", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtStudID.Text = ""
            lblStudName.Text = ""
            lblIC.Text = ""
            txtStudID.Focus()
        End If
    End Sub

    Private Sub btnCheckStud_Click(sender As Object, e As EventArgs) Handles btnCheckStud.Click
        borrow.strStudID = txtStudID.Text
        SearchStudent(borrow.strStudID)
        borrow.strStudName = lblStudName.Text
    End Sub

    Private Sub SearchBorrowedBook(strBookID)
        Dim connection As New SqlConnection
        connection.ConnectionString = "Data Source =  (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\Sim Ka Yee\Documents\Tarc\Diploma\Year 2 Sem 2\Windows Application Programming\Library System\Library System\TestingDatabase1.mdf; Integrated Security = true"
        Dim command As New SqlCommand("Select * From Borrowed_Book
                                       Where BookID = @bookID", connection)
        command.Parameters.AddWithValue("@bookID", returnBook.strBookID)
        Dim adapter As New SqlDataAdapter(command)
        Dim table As New DataTable
        adapter.Fill(table)

        If table.Rows.Count() > 0 Then
            viewBorrowedBook.DataSource = table
        Else
            MessageBox.Show("No Book Data Found.", "TARC Library", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            For i = viewBorrowedBook.Rows.Count - 2 To 0 Step -1
                viewBorrowedBook.Rows.RemoveAt(i)
            Next
            txtBookID2.SelectAll()
        End If
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        returnBook.strBookID = txtBookID2.Text
        SearchBorrowedBook(returnBook.strBookID)
    End Sub

    Private Sub btnReturn2_Click(sender As Object, e As EventArgs) Handles btnReturn2.Click
        If cmbQtyReturn.Items.Count() = 0 Then
            MessageBox.Show("Please select a row from the table.", "TARC Library", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        ElseIf cmbQtyReturn.SelectedIndex = -1 Then
            MessageBox.Show("Please choose the quantity return.", "TARC Library", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        Else
            returnBook.intQtyReturn = cmbQtyReturn.SelectedItem
            Dim return1 As DialogResult = MessageBox.Show("Sure to return the book(s)?", "TARC Library", MessageBoxButtons.YesNo)

            If return1 = DialogResult.Yes Then
                Dim connection As New SqlConnection
                connection.ConnectionString = "Data Source =  (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\Sim Ka Yee\Documents\Tarc\Diploma\Year 2 Sem 2\Windows Application Programming\Library System\Library System\TestingDatabase1.mdf; Integrated Security = true"
                connection.Open()
                If returnBook.intQtyBorrow = returnBook.intQtyReturn Then
                    Dim command As New SqlCommand("DELETE FROM Borrowed_Book
                                                   WHERE bookID = @bookID AND studentID = @studID AND 
                                                   quantityBorrow = @qty AND returnDate = @date", connection)
                    command.Parameters.AddWithValue("@bookID", returnBook.strBookID)
                    command.Parameters.AddWithValue("@studID", returnBook.strStudID)
                    command.Parameters.AddWithValue("@qty", returnBook.intQtyBorrow)
                    command.Parameters.AddWithValue("@date", returnBook.returnDate)
                    viewBorrowedBook.Rows.RemoveAt(selectedRowIndex)

                    Dim command1 As New SqlCommand("UPDATE book SET QuantityAvailable = QuantityAvailable + @qty
                                                    WHERE BookID = @bookID", connection)
                    command1.Parameters.AddWithValue("@bookID", returnBook.strBookID)
                    command1.Parameters.AddWithValue("@qty", returnBook.intQtyReturn)

                    If command.ExecuteNonQuery() = 1 And command1.ExecuteNonQuery() = 1 Then
                        MessageBox.Show("Successfully Return.", "TARC Library", MessageBoxButtons.OK)
                    End If
                Else
                    Dim intDiff As Integer = returnBook.intQtyBorrow - returnBook.intQtyReturn
                    Dim command As New SqlCommand("UPDATE borrowed_book SET QuantityBorrow = @diff
                                                   WHERE bookID = @bookID AND studentID = @studID AND 
                                                   quantityBorrow = @qty AND returnDate = @date", connection)
                    command.Parameters.AddWithValue("@diff", intDiff)
                    command.Parameters.AddWithValue("@bookID", returnBook.strBookID)
                    command.Parameters.AddWithValue("@studID", returnBook.strStudID)
                    command.Parameters.AddWithValue("@qty", returnBook.intQtyBorrow)
                    command.Parameters.AddWithValue("@date", returnBook.returnDate)

                    Dim command1 As New SqlCommand("UPDATE book SET QuantityAvailable = QuantityAvailable + @qty
                                                    WHERE BookID = @bookID", connection)
                    command1.Parameters.AddWithValue("@bookID", returnBook.strBookID)
                    command1.Parameters.AddWithValue("@qty", returnBook.intQtyReturn)

                    If command.ExecuteNonQuery() = 1 And command1.ExecuteNonQuery() = 1 Then
                        MessageBox.Show("Successfully Return.", "TARC Library", MessageBoxButtons.OK)
                        btnReturn_Click(sender, e)
                    End If
                End If
                connection.Close()
            End If
        End If
    End Sub

    Private Sub btnPayFine_Click(sender As Object, e As EventArgs) Handles btnPayFine.Click
        Dim reason As String

        If rabDamage.Checked = True Then
            finePay.strReason = rabDamage.Text
            reason = rabDamage.Text
        Else
            finePay.strReason = rabLost.Text
            reason = rabLost.Text
        End If

        Dim payfine As DialogResult = MessageBox.Show("Sure to proceed to the fine payment page?", "TARC Library", MessageBoxButtons.YesNo)

        If payfine = DialogResult.Yes Then
            returnBook.intQtyReturn = cmbQtyReturn.SelectedItem
            viewFine.Rows(viewFine.Rows.Count() - 1).Selected = True

            Dim connection As New SqlConnection
            connection.ConnectionString = "Data Source =  (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\Sim Ka Yee\Documents\Tarc\Diploma\Year 2 Sem 2\Windows Application Programming\Library System\Library System\TestingDatabase1.mdf; Integrated Security = true"
            Dim command As New SqlCommand("INSERT INTO Fine_Payment VALUES
                                           (@studID, @studName, @bookID, @bookTitle, @date, @reason, @fine, @status, @qty) ", connection)
            command.Parameters.AddWithValue("@studID", returnBook.strStudID)
            command.Parameters.AddWithValue("@studName", returnBook.strStudName)
            command.Parameters.AddWithValue("@bookID", returnBook.strBookID)
            command.Parameters.AddWithValue("@bookTitle", returnBook.strBookTitle)
            command.Parameters.AddWithValue("@date", returnBook.returnDate)
            command.Parameters.AddWithValue("@reason", reason)
            command.Parameters.AddWithValue("@fine", 50.0 * returnBook.intQtyReturn)
            command.Parameters.AddWithValue("@status", "Unpay")
            command.Parameters.AddWithValue("@qty", returnBook.intQtyReturn)

            connection.Open()
            If returnBook.intQtyBorrow = returnBook.intQtyReturn Then
                Dim command1 As New SqlCommand("DELETE FROM Borrowed_Book
                                                WHERE bookID = @bookID AND studentID = @studID AND 
                                                quantityBorrow = @qty AND returnDate = @date", connection)
                command1.Parameters.AddWithValue("@bookID", returnBook.strBookID)
                command1.Parameters.AddWithValue("@studID", returnBook.strStudID)
                command1.Parameters.AddWithValue("@qty", returnBook.intQtyBorrow)
                command1.Parameters.AddWithValue("@date", returnBook.returnDate)
                viewBorrowedBook.Rows.RemoveAt(selectedRowIndex)

                command1.ExecuteNonQuery()
            Else
                Dim intDiff As Integer = returnBook.intQtyBorrow - returnBook.intQtyReturn
                Dim command1 As New SqlCommand("UPDATE borrowed_book SET QuantityBorrow = @diff
                                                WHERE bookID = @bookID AND studentID = @studID AND 
                                                quantityBorrow = @qty AND returnDate = @date", connection)
                command1.Parameters.AddWithValue("@diff", intDiff)
                command1.Parameters.AddWithValue("@bookID", returnBook.strBookID)
                command1.Parameters.AddWithValue("@studID", returnBook.strStudID)
                command1.Parameters.AddWithValue("@qty", returnBook.intQtyBorrow)
                command1.Parameters.AddWithValue("@date", returnBook.returnDate)

                command1.ExecuteNonQuery()
            End If

            Dim command2 As New SqlCommand("UPDATE book SET Quantity = Quantity - @qty
                                            WHERE BookID = @bookID", connection)
            command2.Parameters.AddWithValue("@bookID", returnBook.strBookID)
            command2.Parameters.AddWithValue("@qty", returnBook.intQtyReturn)

            command.ExecuteNonQuery()
            command2.ExecuteNonQuery()
            btnFine_Click(sender, e)
            connection.Close()
        End If
    End Sub

    Private Sub chkAccident_CheckedChanged(sender As Object, e As EventArgs) Handles chkAccident.CheckedChanged
        If cmbQtyReturn.Items.Count() = 0 Then
            MessageBox.Show("Please select a row from the table.", "TARC Library", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            chkAccident.Checked = False
        ElseIf cmbQtyReturn.SelectedIndex = -1 Then
            MessageBox.Show("Please choose the quantity return.", "TARC Library", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            chkAccident.Checked = False
        Else
            If chkAccident.Checked = True Then
                panelUnexpectedSituation.Enabled = True
                btnReturn2.Enabled = False
            Else
                panelUnexpectedSituation.Enabled = False
                btnReturn2.Enabled = True
            End If
        End If
    End Sub

    Private Sub viewBorrowedBook_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles viewBorrowedBook.CellClick
        cmbQtyReturn.SelectedIndex = -1
        cmbQtyReturn.Items.Clear()

        Dim selectedRow As DataGridViewRow
        selectedRowIndex = e.RowIndex
        selectedRow = viewBorrowedBook.Rows(selectedRowIndex)
        If selectedRow.Index = viewBorrowedBook.Rows.Count() - 1 Or selectedRow.Index = -1 Then
            MessageBox.Show("Please select a row with book data.", "TARC Library", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        Else
            returnBook.strBookID = selectedRow.Cells(0).Value
            returnBook.strBookTitle = selectedRow.Cells(1).Value
            returnBook.returnDate = selectedRow.Cells(5).Value
            returnBook.strStudID = selectedRow.Cells(2).Value
            returnBook.strStudName = selectedRow.Cells(3).Value
            returnBook.intQtyBorrow = selectedRow.Cells(4).Value
            For i = 1 To returnBook.intQtyBorrow Step 1
                cmbQtyReturn.Items.Add(i)
            Next
        End If
        cmbQtyReturn.SelectedIndex = cmbQtyReturn.Items.Count() - 1
    End Sub

    Private Sub btnSearch2_Click(sender As Object, e As EventArgs) Handles btnSearch2.Click
        finePay.strBookID = txtBookID3.Text

        Dim connection As New SqlConnection
        connection.ConnectionString = "Data Source =  (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\Sim Ka Yee\Documents\Tarc\Diploma\Year 2 Sem 2\Windows Application Programming\Library System\Library System\TestingDatabase1.mdf; Integrated Security = true"
        Dim command As New SqlCommand("Select * From Fine_Payment
                                       Where BookID = @bookID AND PayStatus = 'Unpay'", connection)
        command.Parameters.AddWithValue("@bookID", finePay.strBookID)
        Dim adapter As New SqlDataAdapter(command)
        Dim table As New DataTable
        adapter.Fill(table)

        If table.Rows.Count() > 0 Then
            viewFine.DataSource = table
        Else
            MessageBox.Show("No Fine Data Found.", "TARC Library", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            For i = viewFine.Rows.Count - 2 To 0 Step -1
                viewFine.Rows.RemoveAt(i)
            Next
            txtBookID3.Text = ""
            lblOverdueDay.Text = ""
            lblFine.Text = ""
            txtCash.Text = ""
            lblChange.Text = ""
            txtBookID3.Focus()
        End If
    End Sub

    Private Sub viewFine_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles viewFine.CellClick
        Dim selectedRow As DataGridViewRow
        selectedRowIndex = e.RowIndex
        selectedRow = viewFine.Rows(selectedRowIndex)
        If selectedRow.Index = viewFine.Rows.Count() - 1 Or selectedRow.Index = -1 Then
            MessageBox.Show("Please select a row with book data.", "TARC Library", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        Else
            finePay.strBookID = selectedRow.Cells(2).Value
            finePay.strStudID = selectedRow.Cells(0).Value
            finePay.returnDate = selectedRow.Cells(4).Value
            finePay.strReason = selectedRow.Cells(5).Value
            finePay.dblCharge = selectedRow.Cells(6).Value
            finePay.intQty = selectedRow.Cells(8).Value

            Dim span = currentDate - finePay.returnDate
            Dim overdueDay As Integer = span.TotalDays - 1

            If overdueDay <= 0 Then
                lblOverdueDay.Text = "-"
            Else
                lblOverdueDay.Text = FormatNumber(overdueDay, 0)
            End If
            lblFine.Text = FormatCurrency(finePay.dblCharge, 2)
        End If
    End Sub

    Private Sub btnDisplayAll_Click(sender As Object, e As EventArgs) Handles btnDisplayAll.Click
        Dim connection As New SqlConnection
        connection.ConnectionString = "Data Source =  (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\Sim Ka Yee\Documents\Tarc\Diploma\Year 2 Sem 2\Windows Application Programming\Library System\Library System\TestingDatabase1.mdf; Integrated Security = true"
        Dim command As New SqlCommand("Select * From Fine_Payment WHERE PayStatus = 'Unpay'", connection)
        Dim adapter As New SqlDataAdapter(command)
        Dim table As New DataTable
        adapter.Fill(table)

        viewFine.DataSource = table
    End Sub

    Private Sub btnCharge_Click(sender As Object, e As EventArgs) Handles btnCharge.Click
        If lblOverdueDay.Text = "" Or lblFine.Text = "" Then
            MessageBox.Show("Please select a row from the table to pay fine.", "TARC Library", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        Else
            Dim dblCash, dblChange As Double

            Try
                dblCash = CDbl(txtCash.Text)
                If dblCash < 0 Or dblCash < lblFine.Text Then
                    MessageBox.Show("The value cannot be smaller than the fine amount.", "TARC Library", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    txtCash.Text = ""
                    txtCash.Focus()
                Else
                    dblChange = dblCash - lblFine.Text

                    lblChange.Text = FormatCurrency(dblChange, 2)
                    intConfirmCharge += 1
                End If
            Catch ex As Exception
                MessageBox.Show("Invalid cash input.", "TARC Library", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                txtCash.Text = ""
                txtCash.Focus()
            End Try
        End If
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        intConfirmCharge = 0
        btnCharge_Click(sender, e)

        If intConfirmCharge <> 0 Then
            Dim connection As New SqlConnection
            connection.ConnectionString = "Data Source =  (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\Sim Ka Yee\Documents\Tarc\Diploma\Year 2 Sem 2\Windows Application Programming\Library System\Library System\TestingDatabase1.mdf; Integrated Security = true"
            Dim command As New SqlCommand("UPDATE fine_payment SET PayStatus = 'Payed'
                                           WHERE bookID = @bookID AND studentID = @studID AND returnDate = @date AND
                                           Reason = @reason AND fineCharged = @fine", connection)
            command.Parameters.AddWithValue("@bookID", finePay.strBookID)
            command.Parameters.AddWithValue("@studID", finePay.strStudID)
            command.Parameters.AddWithValue("@date", finePay.returnDate)
            command.Parameters.AddWithValue("@reason", finePay.strReason)
            command.Parameters.AddWithValue("@fine", finePay.dblCharge)

            connection.Open()
            If command.ExecuteNonQuery() = 1 Then
                MessageBox.Show("The database has been succesfully updated.", "TARC Library", MessageBoxButtons.OK)
                btnDisplayAll_Click(sender, e)
                If finePay.strReason = "Overdue" Then
                    Dim command1 As New SqlCommand("UPDATE Book SET QuantityAvailable = QuantityAvailable + @qty
                                                    WHERE bookID = @bookID", connection)
                    command1.Parameters.AddWithValue("@qty", finePay.intQty)
                    command1.Parameters.AddWithValue("@bookID", finePay.strBookID)
                    command1.ExecuteNonQuery()
                End If
                txtBookID3.Text = ""
                lblOverdueDay.Text = ""
                lblFine.Text = ""
                txtCash.Text = ""
                lblChange.Text = ""
            End If
            connection.Close()
        End If
    End Sub

    Private Sub btnDisplayAll2_Click(sender As Object, e As EventArgs) Handles btnDisplayAll2.Click
        btnReturn_Click(sender, e)
    End Sub

    Private Sub btnConfirm_Click(sender As Object, e As EventArgs) Handles btnConfirm.Click
        borrow.returnDate = currentDate.AddDays(7.0#)

        If confirmBook = 0 Or confirmStud = 0 Or cmbQtyBorrow.SelectedIndex = -1 Then
            MessageBox.Show("Please insert all the book details, student details, and the quantity borrow.",
                            "TARC Library", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        Else
            borrow.intQtyBorrow = cmbQtyBorrow.SelectedItem

            Dim confirm As DialogResult = MessageBox.Show("Sure to borrow the book(s)?", "TARC Library", MessageBoxButtons.YesNo)

            If confirm = DialogResult.Yes Then
                Dim connection As New SqlConnection
                connection.ConnectionString = "Data Source =  (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\Sim Ka Yee\Documents\Tarc\Diploma\Year 2 Sem 2\Windows Application Programming\Library System\Library System\TestingDatabase1.mdf; Integrated Security = true"
                Dim command As New SqlCommand("INSERT INTO Borrowed_Book VALUES
                                               (@bookID, @bookTitle, @studID, @studName, @qty, @date) ", connection)
                command.Parameters.AddWithValue("@bookID", borrow.strBookID)
                command.Parameters.AddWithValue("@bookTitle", borrow.strBookTitle)
                command.Parameters.AddWithValue("@studID", borrow.strStudID)
                command.Parameters.AddWithValue("@studName", borrow.strStudName)
                command.Parameters.AddWithValue("@qty", borrow.intQtyBorrow)
                command.Parameters.AddWithValue("@date", borrow.returnDate)

                Dim command1 As New SqlCommand("UPDATE book SET QuantityAvailable = QuantityAvailable - @qty
                                                WHERE BookID = @bookID", connection)
                command1.Parameters.AddWithValue("@bookID", borrow.strBookID)
                command1.Parameters.AddWithValue("@qty", borrow.intQtyBorrow)

                connection.Open()

                If command.ExecuteNonQuery() = 1 And command1.ExecuteNonQuery() = 1 Then
                    MessageBox.Show("Return Date : " & borrow.returnDate.ToString("dd-MM-yyyy") & vbCr & vbCr &
                                    "All the relevant data has been added into the database.", "TARC Library", MessageBoxButtons.OK)
                    txtBookID.Text = ""
                    lblTitle.Text = ""
                    lblQuantity.Text = ""
                    txtStudID.Text = ""
                    lblStudName.Text = ""
                    lblIC.Text = ""
                    cmbQtyBorrow.SelectedIndex = -1
                    cmbQtyBorrow.Items.Clear()
                End If

                connection.Close()
            End If
        End If
    End Sub
End Class