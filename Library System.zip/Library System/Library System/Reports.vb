﻿Public Class frmReports
    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        End
    End Sub
End Class