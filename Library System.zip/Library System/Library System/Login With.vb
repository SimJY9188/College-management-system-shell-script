﻿Public Class frmLoginWith
    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        End
    End Sub

    Private Sub frmLoginWith_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        btnStudent.BackColor = Color.Transparent
        btnLibrarian.BackColor = Color.Transparent
        btnAdmin.BackColor = Color.Transparent
    End Sub

    Private Sub btnStudent_Click(sender As Object, e As EventArgs) Handles btnStudent.Click
        Me.Hide()
        frmStudentAction.Show()
    End Sub

    Private Sub btnLibrarian_Click(sender As Object, e As EventArgs) Handles btnLibrarian.Click
        Me.Hide()
        frmLibrarianAction.Show()
    End Sub

    Private Sub btnAdmin_Click(sender As Object, e As EventArgs) Handles btnAdmin.Click
        Me.Hide()
        frmAdminAction.Show()
    End Sub
End Class