﻿Imports System.Data.SqlClient

Public Class frmBlackList
    Dim connection As New SqlConnection("Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\Sim Ka Yee\Documents\Tarc\Diploma\Year 2 Sem 2\Windows Application Programming\Library System\Library System\TestingDatabase1.mdf; Integrated Security = true")

    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        End
    End Sub

    Private Sub frmBlackList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim command As New SqlCommand("SELECT * From BlackList", connection)
        Dim adapter As New SqlDataAdapter(command)
        Dim table As New DataTable
        adapter.Fill(table)
        connection.Open()
        viewBlackList.DataSource = table
        lblItem.Text = table.Rows.Count() & " Blacklisted Student(s)"
        connection.Close()
    End Sub

    Private Sub picBack_Click(sender As Object, e As EventArgs) Handles picBack.Click
        Me.Hide()
        frmAdminAction.Show()
    End Sub
End Class