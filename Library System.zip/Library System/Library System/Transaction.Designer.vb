﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmTransaction
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmTransaction))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.picBack = New System.Windows.Forms.PictureBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pnlLeftFine = New System.Windows.Forms.FlowLayoutPanel()
        Me.pnlLeftReturn = New System.Windows.Forms.FlowLayoutPanel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.btnFine = New System.Windows.Forms.Button()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.btnReturn = New System.Windows.Forms.Button()
        Me.pnlLeftBorrow = New System.Windows.Forms.FlowLayoutPanel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnBorrow = New System.Windows.Forms.Button()
        Me.viewBorrowedBook = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.BookIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BookTitleDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StudentIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StudentNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.QuantityBorrow = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReturnDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BorrowedBookDataTableBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.lblClose = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.BunifuElipse1 = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.btnCheckBook = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.panelBorrow = New System.Windows.Forms.Panel()
        Me.cmbQtyBorrow = New System.Windows.Forms.ComboBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.btnConfirm = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.lblStudentDetails = New System.Windows.Forms.Label()
        Me.panelStudentDetails = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btnCheckStud = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.lblIC = New System.Windows.Forms.TextBox()
        Me.FlowLayoutPanel2 = New System.Windows.Forms.FlowLayoutPanel()
        Me.txtStudID = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel3 = New System.Windows.Forms.FlowLayoutPanel()
        Me.lblStudName = New System.Windows.Forms.TextBox()
        Me.lblBookDetails = New System.Windows.Forms.Label()
        Me.panelBookDetails = New System.Windows.Forms.Panel()
        Me.paneltxtBookID = New System.Windows.Forms.FlowLayoutPanel()
        Me.txtBookID = New System.Windows.Forms.TextBox()
        Me.paneltxtQuantity = New System.Windows.Forms.FlowLayoutPanel()
        Me.lblQuantity = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.panellblTitle = New System.Windows.Forms.FlowLayoutPanel()
        Me.lblTitle = New System.Windows.Forms.TextBox()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.ToolTip2 = New System.Windows.Forms.ToolTip(Me.components)
        Me.btnSearch = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.paneltxtBookID2 = New System.Windows.Forms.FlowLayoutPanel()
        Me.txtBookID2 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnReturn2 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.panelReturn = New System.Windows.Forms.Panel()
        Me.btnDisplayAll2 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.chkAccident = New System.Windows.Forms.CheckBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.panelUnexpectedSituation = New System.Windows.Forms.Panel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rabLost = New System.Windows.Forms.RadioButton()
        Me.rabDamage = New System.Windows.Forms.RadioButton()
        Me.btnPayFine = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.cmbQtyReturn = New System.Windows.Forms.ComboBox()
        Me.panelFine = New System.Windows.Forms.Panel()
        Me.viewFine = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.StudentIDDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StudentNameDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BookIDDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BookTitleDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReturnDateDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReasonDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FineChargedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PayStatusDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.QuantityDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FinePaymentDataTableBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.btnDisplayAll = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.btnSave = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.FlowLayoutPanel9 = New System.Windows.Forms.FlowLayoutPanel()
        Me.txtBookID3 = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.btnSearch2 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.btnCharge = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.FlowLayoutPanel5 = New System.Windows.Forms.FlowLayoutPanel()
        Me.lblFine = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel6 = New System.Windows.Forms.FlowLayoutPanel()
        Me.lblChange = New System.Windows.Forms.TextBox()
        Me.FlowLayoutPanel7 = New System.Windows.Forms.FlowLayoutPanel()
        Me.lblOverdueDay = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel8 = New System.Windows.Forms.FlowLayoutPanel()
        Me.txtCash = New System.Windows.Forms.TextBox()
        Me.Panel4.SuspendLayout()
        CType(Me.picBack, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.viewBorrowedBook, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BorrowedBookDataTableBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.panelBorrow.SuspendLayout()
        Me.panelStudentDetails.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.FlowLayoutPanel2.SuspendLayout()
        Me.FlowLayoutPanel3.SuspendLayout()
        Me.panelBookDetails.SuspendLayout()
        Me.paneltxtBookID.SuspendLayout()
        Me.paneltxtQuantity.SuspendLayout()
        Me.panellblTitle.SuspendLayout()
        Me.paneltxtBookID2.SuspendLayout()
        Me.panelReturn.SuspendLayout()
        Me.panelUnexpectedSituation.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.panelFine.SuspendLayout()
        CType(Me.viewFine, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FinePaymentDataTableBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FlowLayoutPanel9.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.FlowLayoutPanel5.SuspendLayout()
        Me.FlowLayoutPanel6.SuspendLayout()
        Me.FlowLayoutPanel7.SuspendLayout()
        Me.FlowLayoutPanel8.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(67, Byte), Integer))
        Me.Panel4.Controls.Add(Me.picBack)
        Me.Panel4.Controls.Add(Me.Panel3)
        Me.Panel4.Controls.Add(Me.Panel1)
        Me.Panel4.Controls.Add(Me.Label1)
        Me.Panel4.Controls.Add(Me.pnlLeftFine)
        Me.Panel4.Controls.Add(Me.pnlLeftReturn)
        Me.Panel4.Controls.Add(Me.PictureBox2)
        Me.Panel4.Controls.Add(Me.btnFine)
        Me.Panel4.Controls.Add(Me.PictureBox4)
        Me.Panel4.Controls.Add(Me.btnReturn)
        Me.Panel4.Controls.Add(Me.pnlLeftBorrow)
        Me.Panel4.Controls.Add(Me.PictureBox1)
        Me.Panel4.Controls.Add(Me.btnBorrow)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Margin = New System.Windows.Forms.Padding(5)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(239, 500)
        Me.Panel4.TabIndex = 0
        '
        'picBack
        '
        Me.picBack.Cursor = System.Windows.Forms.Cursors.Default
        Me.picBack.Image = CType(resources.GetObject("picBack.Image"), System.Drawing.Image)
        Me.picBack.Location = New System.Drawing.Point(2, 3)
        Me.picBack.Name = "picBack"
        Me.picBack.Size = New System.Drawing.Size(33, 34)
        Me.picBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBack.TabIndex = 18
        Me.picBack.TabStop = False
        Me.ToolTip1.SetToolTip(Me.picBack, "Click to go back")
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.White
        Me.Panel3.Location = New System.Drawing.Point(14, 116)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(44, 8)
        Me.Panel3.TabIndex = 13
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Location = New System.Drawing.Point(32, 98)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(8, 44)
        Me.Panel1.TabIndex = 12
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 23.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(42, 71)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(187, 42)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Transaction"
        '
        'pnlLeftFine
        '
        Me.pnlLeftFine.BackColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer))
        Me.pnlLeftFine.Location = New System.Drawing.Point(-2, 284)
        Me.pnlLeftFine.Name = "pnlLeftFine"
        Me.pnlLeftFine.Size = New System.Drawing.Size(10, 34)
        Me.pnlLeftFine.TabIndex = 10
        '
        'pnlLeftReturn
        '
        Me.pnlLeftReturn.BackColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer))
        Me.pnlLeftReturn.Location = New System.Drawing.Point(-2, 232)
        Me.pnlLeftReturn.Name = "pnlLeftReturn"
        Me.pnlLeftReturn.Size = New System.Drawing.Size(10, 34)
        Me.pnlLeftReturn.TabIndex = 7
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(25, 284)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(33, 34)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 9
        Me.PictureBox2.TabStop = False
        '
        'btnFine
        '
        Me.btnFine.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnFine.FlatAppearance.BorderSize = 0
        Me.btnFine.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnFine.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFine.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btnFine.Location = New System.Drawing.Point(-2, 284)
        Me.btnFine.Name = "btnFine"
        Me.btnFine.Size = New System.Drawing.Size(241, 34)
        Me.btnFine.TabIndex = 8
        Me.btnFine.Text = "    Fine Payment"
        Me.btnFine.UseVisualStyleBackColor = True
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(24, 232)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(30, 34)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 6
        Me.PictureBox4.TabStop = False
        '
        'btnReturn
        '
        Me.btnReturn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnReturn.FlatAppearance.BorderSize = 0
        Me.btnReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnReturn.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReturn.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btnReturn.Location = New System.Drawing.Point(-2, 232)
        Me.btnReturn.Name = "btnReturn"
        Me.btnReturn.Size = New System.Drawing.Size(241, 34)
        Me.btnReturn.TabIndex = 5
        Me.btnReturn.Text = "  Return Book"
        Me.btnReturn.UseVisualStyleBackColor = True
        '
        'pnlLeftBorrow
        '
        Me.pnlLeftBorrow.BackColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer))
        Me.pnlLeftBorrow.Location = New System.Drawing.Point(-2, 182)
        Me.pnlLeftBorrow.Name = "pnlLeftBorrow"
        Me.pnlLeftBorrow.Size = New System.Drawing.Size(10, 34)
        Me.pnlLeftBorrow.TabIndex = 4
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(24, 182)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(30, 34)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'btnBorrow
        '
        Me.btnBorrow.FlatAppearance.BorderSize = 0
        Me.btnBorrow.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBorrow.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBorrow.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btnBorrow.Location = New System.Drawing.Point(-2, 182)
        Me.btnBorrow.Name = "btnBorrow"
        Me.btnBorrow.Size = New System.Drawing.Size(241, 34)
        Me.btnBorrow.TabIndex = 2
        Me.btnBorrow.Text = "   Borrow Book"
        Me.btnBorrow.UseVisualStyleBackColor = True
        '
        'viewBorrowedBook
        '
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.viewBorrowedBook.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.viewBorrowedBook.AutoGenerateColumns = False
        Me.viewBorrowedBook.BackgroundColor = System.Drawing.Color.Gainsboro
        Me.viewBorrowedBook.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.viewBorrowedBook.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(49, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(57, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(245, Byte), Integer))
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.viewBorrowedBook.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.viewBorrowedBook.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.viewBorrowedBook.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.BookIDDataGridViewTextBoxColumn, Me.BookTitleDataGridViewTextBoxColumn, Me.StudentIDDataGridViewTextBoxColumn, Me.StudentNameDataGridViewTextBoxColumn, Me.QuantityBorrow, Me.ReturnDateDataGridViewTextBoxColumn})
        Me.viewBorrowedBook.DataSource = Me.BorrowedBookDataTableBindingSource
        Me.viewBorrowedBook.DoubleBuffered = True
        Me.viewBorrowedBook.EnableHeadersVisualStyles = False
        Me.viewBorrowedBook.HeaderBgColor = System.Drawing.Color.FromArgb(CType(CType(49, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.viewBorrowedBook.HeaderForeColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(245, Byte), Integer))
        Me.viewBorrowedBook.Location = New System.Drawing.Point(40, 72)
        Me.viewBorrowedBook.Name = "viewBorrowedBook"
        Me.viewBorrowedBook.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.viewBorrowedBook.Size = New System.Drawing.Size(645, 163)
        Me.viewBorrowedBook.TabIndex = 19
        '
        'BookIDDataGridViewTextBoxColumn
        '
        Me.BookIDDataGridViewTextBoxColumn.DataPropertyName = "BookID"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BookIDDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle3
        Me.BookIDDataGridViewTextBoxColumn.HeaderText = "Book_ID"
        Me.BookIDDataGridViewTextBoxColumn.Name = "BookIDDataGridViewTextBoxColumn"
        Me.BookIDDataGridViewTextBoxColumn.ReadOnly = True
        Me.BookIDDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.BookIDDataGridViewTextBoxColumn.Width = 74
        '
        'BookTitleDataGridViewTextBoxColumn
        '
        Me.BookTitleDataGridViewTextBoxColumn.DataPropertyName = "BookTitle"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BookTitleDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle4
        Me.BookTitleDataGridViewTextBoxColumn.HeaderText = "           Book_Title"
        Me.BookTitleDataGridViewTextBoxColumn.Name = "BookTitleDataGridViewTextBoxColumn"
        Me.BookTitleDataGridViewTextBoxColumn.ReadOnly = True
        Me.BookTitleDataGridViewTextBoxColumn.Width = 200
        '
        'StudentIDDataGridViewTextBoxColumn
        '
        Me.StudentIDDataGridViewTextBoxColumn.DataPropertyName = "StudentID"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.StudentIDDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle5
        Me.StudentIDDataGridViewTextBoxColumn.HeaderText = "Student_ID"
        Me.StudentIDDataGridViewTextBoxColumn.Name = "StudentIDDataGridViewTextBoxColumn"
        Me.StudentIDDataGridViewTextBoxColumn.ReadOnly = True
        Me.StudentIDDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.StudentIDDataGridViewTextBoxColumn.Width = 92
        '
        'StudentNameDataGridViewTextBoxColumn
        '
        Me.StudentNameDataGridViewTextBoxColumn.DataPropertyName = "StudentName"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.StudentNameDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle6
        Me.StudentNameDataGridViewTextBoxColumn.HeaderText = "       Student_Name"
        Me.StudentNameDataGridViewTextBoxColumn.Name = "StudentNameDataGridViewTextBoxColumn"
        Me.StudentNameDataGridViewTextBoxColumn.ReadOnly = True
        Me.StudentNameDataGridViewTextBoxColumn.Width = 200
        '
        'QuantityBorrow
        '
        Me.QuantityBorrow.DataPropertyName = "QuantityBorrow"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.QuantityBorrow.DefaultCellStyle = DataGridViewCellStyle7
        Me.QuantityBorrow.HeaderText = "Quantity_Borrow"
        Me.QuantityBorrow.Name = "QuantityBorrow"
        Me.QuantityBorrow.ReadOnly = True
        Me.QuantityBorrow.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.QuantityBorrow.Width = 140
        '
        'ReturnDateDataGridViewTextBoxColumn
        '
        Me.ReturnDateDataGridViewTextBoxColumn.DataPropertyName = "ReturnDate"
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ReturnDateDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle8
        Me.ReturnDateDataGridViewTextBoxColumn.HeaderText = "Return_Date"
        Me.ReturnDateDataGridViewTextBoxColumn.Name = "ReturnDateDataGridViewTextBoxColumn"
        Me.ReturnDateDataGridViewTextBoxColumn.ReadOnly = True
        Me.ReturnDateDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.ReturnDateDataGridViewTextBoxColumn.Width = 107
        '
        'BorrowedBookDataTableBindingSource
        '
        Me.BorrowedBookDataTableBindingSource.DataSource = GetType(Library_System.TestingDatabase1DataSet.Borrowed_BookDataTable)
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(29, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), System.Drawing.Image)
        Me.Panel2.Controls.Add(Me.lblClose)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(239, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(727, 36)
        Me.Panel2.TabIndex = 1
        '
        'lblClose
        '
        Me.lblClose.BackColor = System.Drawing.Color.Transparent
        Me.lblClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblClose.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClose.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblClose.Location = New System.Drawing.Point(693, -1)
        Me.lblClose.Name = "lblClose"
        Me.lblClose.Size = New System.Drawing.Size(31, 32)
        Me.lblClose.TabIndex = 2
        Me.lblClose.Text = "x"
        Me.lblClose.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.ToolTip2.SetToolTip(Me.lblClose, "Click to close")
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(22, 18)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(92, 23)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Book ID:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'BunifuElipse1
        '
        Me.BunifuElipse1.ElipseRadius = 20
        Me.BunifuElipse1.TargetControl = Me
        '
        'btnCheckBook
        '
        Me.btnCheckBook.ActiveBorderThickness = 1
        Me.btnCheckBook.ActiveCornerRadius = 20
        Me.btnCheckBook.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnCheckBook.ActiveForecolor = System.Drawing.Color.White
        Me.btnCheckBook.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnCheckBook.BackColor = System.Drawing.Color.Transparent
        Me.btnCheckBook.BackgroundImage = CType(resources.GetObject("btnCheckBook.BackgroundImage"), System.Drawing.Image)
        Me.btnCheckBook.ButtonText = "Check Book"
        Me.btnCheckBook.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCheckBook.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCheckBook.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnCheckBook.IdleBorderThickness = 1
        Me.btnCheckBook.IdleCornerRadius = 20
        Me.btnCheckBook.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnCheckBook.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.btnCheckBook.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnCheckBook.Location = New System.Drawing.Point(317, 6)
        Me.btnCheckBook.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnCheckBook.Name = "btnCheckBook"
        Me.btnCheckBook.Size = New System.Drawing.Size(118, 44)
        Me.btnCheckBook.TabIndex = 7
        Me.btnCheckBook.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'panelBorrow
        '
        Me.panelBorrow.BackgroundImage = CType(resources.GetObject("panelBorrow.BackgroundImage"), System.Drawing.Image)
        Me.panelBorrow.Controls.Add(Me.cmbQtyBorrow)
        Me.panelBorrow.Controls.Add(Me.Label11)
        Me.panelBorrow.Controls.Add(Me.btnConfirm)
        Me.panelBorrow.Controls.Add(Me.lblStudentDetails)
        Me.panelBorrow.Controls.Add(Me.panelStudentDetails)
        Me.panelBorrow.Controls.Add(Me.lblBookDetails)
        Me.panelBorrow.Controls.Add(Me.panelBookDetails)
        Me.panelBorrow.Location = New System.Drawing.Point(239, 35)
        Me.panelBorrow.Name = "panelBorrow"
        Me.panelBorrow.Size = New System.Drawing.Size(727, 465)
        Me.panelBorrow.TabIndex = 8
        '
        'cmbQtyBorrow
        '
        Me.cmbQtyBorrow.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbQtyBorrow.FormattingEnabled = True
        Me.cmbQtyBorrow.Location = New System.Drawing.Point(459, 403)
        Me.cmbQtyBorrow.MaxDropDownItems = 20
        Me.cmbQtyBorrow.Name = "cmbQtyBorrow"
        Me.cmbQtyBorrow.Size = New System.Drawing.Size(74, 31)
        Me.cmbQtyBorrow.TabIndex = 18
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(311, 407)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(140, 23)
        Me.Label11.TabIndex = 14
        Me.Label11.Text = "Quantity Borrow:"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnConfirm
        '
        Me.btnConfirm.ActiveBorderThickness = 1
        Me.btnConfirm.ActiveCornerRadius = 20
        Me.btnConfirm.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnConfirm.ActiveForecolor = System.Drawing.Color.White
        Me.btnConfirm.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnConfirm.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnConfirm.BackgroundImage = CType(resources.GetObject("btnConfirm.BackgroundImage"), System.Drawing.Image)
        Me.btnConfirm.ButtonText = "Confirm"
        Me.btnConfirm.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnConfirm.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConfirm.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnConfirm.IdleBorderThickness = 1
        Me.btnConfirm.IdleCornerRadius = 20
        Me.btnConfirm.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnConfirm.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.btnConfirm.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnConfirm.Location = New System.Drawing.Point(584, 396)
        Me.btnConfirm.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnConfirm.Name = "btnConfirm"
        Me.btnConfirm.Size = New System.Drawing.Size(114, 44)
        Me.btnConfirm.TabIndex = 14
        Me.btnConfirm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblStudentDetails
        '
        Me.lblStudentDetails.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblStudentDetails.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStudentDetails.ForeColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.lblStudentDetails.Image = CType(resources.GetObject("lblStudentDetails.Image"), System.Drawing.Image)
        Me.lblStudentDetails.Location = New System.Drawing.Point(501, 214)
        Me.lblStudentDetails.Name = "lblStudentDetails"
        Me.lblStudentDetails.Size = New System.Drawing.Size(185, 33)
        Me.lblStudentDetails.TabIndex = 15
        Me.lblStudentDetails.Text = "Student Details"
        Me.lblStudentDetails.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'panelStudentDetails
        '
        Me.panelStudentDetails.BackColor = System.Drawing.Color.Transparent
        Me.panelStudentDetails.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.panelStudentDetails.Controls.Add(Me.Label7)
        Me.panelStudentDetails.Controls.Add(Me.btnCheckStud)
        Me.panelStudentDetails.Controls.Add(Me.FlowLayoutPanel1)
        Me.panelStudentDetails.Controls.Add(Me.FlowLayoutPanel2)
        Me.panelStudentDetails.Controls.Add(Me.Label8)
        Me.panelStudentDetails.Controls.Add(Me.Label9)
        Me.panelStudentDetails.Controls.Add(Me.FlowLayoutPanel3)
        Me.panelStudentDetails.Location = New System.Drawing.Point(20, 235)
        Me.panelStudentDetails.Name = "panelStudentDetails"
        Me.panelStudentDetails.Size = New System.Drawing.Size(684, 141)
        Me.panelStudentDetails.TabIndex = 16
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(22, 18)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(128, 23)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Student ID:"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnCheckStud
        '
        Me.btnCheckStud.ActiveBorderThickness = 1
        Me.btnCheckStud.ActiveCornerRadius = 20
        Me.btnCheckStud.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnCheckStud.ActiveForecolor = System.Drawing.Color.White
        Me.btnCheckStud.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnCheckStud.BackColor = System.Drawing.Color.Transparent
        Me.btnCheckStud.BackgroundImage = CType(resources.GetObject("btnCheckStud.BackgroundImage"), System.Drawing.Image)
        Me.btnCheckStud.ButtonText = "Check Student"
        Me.btnCheckStud.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCheckStud.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCheckStud.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnCheckStud.IdleBorderThickness = 1
        Me.btnCheckStud.IdleCornerRadius = 20
        Me.btnCheckStud.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnCheckStud.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.btnCheckStud.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnCheckStud.Location = New System.Drawing.Point(303, 6)
        Me.btnCheckStud.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnCheckStud.Name = "btnCheckStud"
        Me.btnCheckStud.Size = New System.Drawing.Size(135, 44)
        Me.btnCheckStud.TabIndex = 7
        Me.btnCheckStud.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.BackColor = System.Drawing.Color.White
        Me.FlowLayoutPanel1.Controls.Add(Me.lblIC)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(155, 91)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Padding = New System.Windows.Forms.Padding(1)
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(241, 31)
        Me.FlowLayoutPanel1.TabIndex = 11
        '
        'lblIC
        '
        Me.lblIC.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblIC.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblIC.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblIC.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblIC.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIC.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lblIC.Location = New System.Drawing.Point(4, 4)
        Me.lblIC.Name = "lblIC"
        Me.lblIC.ReadOnly = True
        Me.lblIC.Size = New System.Drawing.Size(233, 23)
        Me.lblIC.TabIndex = 0
        '
        'FlowLayoutPanel2
        '
        Me.FlowLayoutPanel2.BackColor = System.Drawing.Color.White
        Me.FlowLayoutPanel2.Controls.Add(Me.txtStudID)
        Me.FlowLayoutPanel2.Location = New System.Drawing.Point(155, 14)
        Me.FlowLayoutPanel2.Name = "FlowLayoutPanel2"
        Me.FlowLayoutPanel2.Padding = New System.Windows.Forms.Padding(1)
        Me.FlowLayoutPanel2.Size = New System.Drawing.Size(103, 31)
        Me.FlowLayoutPanel2.TabIndex = 5
        '
        'txtStudID
        '
        Me.txtStudID.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtStudID.Dock = System.Windows.Forms.DockStyle.Top
        Me.txtStudID.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStudID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtStudID.Location = New System.Drawing.Point(4, 4)
        Me.txtStudID.Name = "txtStudID"
        Me.txtStudID.Size = New System.Drawing.Size(95, 23)
        Me.txtStudID.TabIndex = 0
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(22, 94)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(115, 23)
        Me.Label8.TabIndex = 10
        Me.Label8.Text = "IC Num.:"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(22, 57)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(128, 23)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Student Name:"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'FlowLayoutPanel3
        '
        Me.FlowLayoutPanel3.BackColor = System.Drawing.Color.White
        Me.FlowLayoutPanel3.Controls.Add(Me.lblStudName)
        Me.FlowLayoutPanel3.Location = New System.Drawing.Point(155, 53)
        Me.FlowLayoutPanel3.Name = "FlowLayoutPanel3"
        Me.FlowLayoutPanel3.Padding = New System.Windows.Forms.Padding(1)
        Me.FlowLayoutPanel3.Size = New System.Drawing.Size(456, 31)
        Me.FlowLayoutPanel3.TabIndex = 9
        '
        'lblStudName
        '
        Me.lblStudName.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblStudName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblStudName.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblStudName.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblStudName.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStudName.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lblStudName.Location = New System.Drawing.Point(4, 4)
        Me.lblStudName.Name = "lblStudName"
        Me.lblStudName.ReadOnly = True
        Me.lblStudName.Size = New System.Drawing.Size(448, 23)
        Me.lblStudName.TabIndex = 0
        '
        'lblBookDetails
        '
        Me.lblBookDetails.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblBookDetails.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBookDetails.ForeColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.lblBookDetails.Image = CType(resources.GetObject("lblBookDetails.Image"), System.Drawing.Image)
        Me.lblBookDetails.Location = New System.Drawing.Point(512, 28)
        Me.lblBookDetails.Name = "lblBookDetails"
        Me.lblBookDetails.Size = New System.Drawing.Size(162, 33)
        Me.lblBookDetails.TabIndex = 12
        Me.lblBookDetails.Text = "Book Details"
        Me.lblBookDetails.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'panelBookDetails
        '
        Me.panelBookDetails.BackColor = System.Drawing.Color.Transparent
        Me.panelBookDetails.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.panelBookDetails.Controls.Add(Me.paneltxtBookID)
        Me.panelBookDetails.Controls.Add(Me.Label2)
        Me.panelBookDetails.Controls.Add(Me.btnCheckBook)
        Me.panelBookDetails.Controls.Add(Me.paneltxtQuantity)
        Me.panelBookDetails.Controls.Add(Me.Label4)
        Me.panelBookDetails.Controls.Add(Me.Label3)
        Me.panelBookDetails.Controls.Add(Me.panellblTitle)
        Me.panelBookDetails.Location = New System.Drawing.Point(20, 49)
        Me.panelBookDetails.Name = "panelBookDetails"
        Me.panelBookDetails.Size = New System.Drawing.Size(684, 139)
        Me.panelBookDetails.TabIndex = 14
        '
        'paneltxtBookID
        '
        Me.paneltxtBookID.BackColor = System.Drawing.Color.White
        Me.paneltxtBookID.Controls.Add(Me.txtBookID)
        Me.paneltxtBookID.Location = New System.Drawing.Point(144, 14)
        Me.paneltxtBookID.Name = "paneltxtBookID"
        Me.paneltxtBookID.Padding = New System.Windows.Forms.Padding(1)
        Me.paneltxtBookID.Size = New System.Drawing.Size(110, 31)
        Me.paneltxtBookID.TabIndex = 5
        '
        'txtBookID
        '
        Me.txtBookID.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtBookID.Dock = System.Windows.Forms.DockStyle.Top
        Me.txtBookID.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBookID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtBookID.Location = New System.Drawing.Point(4, 4)
        Me.txtBookID.Name = "txtBookID"
        Me.txtBookID.Size = New System.Drawing.Size(102, 23)
        Me.txtBookID.TabIndex = 0
        '
        'paneltxtQuantity
        '
        Me.paneltxtQuantity.BackColor = System.Drawing.Color.White
        Me.paneltxtQuantity.Controls.Add(Me.lblQuantity)
        Me.paneltxtQuantity.Location = New System.Drawing.Point(144, 91)
        Me.paneltxtQuantity.Name = "paneltxtQuantity"
        Me.paneltxtQuantity.Padding = New System.Windows.Forms.Padding(1)
        Me.paneltxtQuantity.Size = New System.Drawing.Size(83, 31)
        Me.paneltxtQuantity.TabIndex = 11
        '
        'lblQuantity
        '
        Me.lblQuantity.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblQuantity.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblQuantity.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblQuantity.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblQuantity.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuantity.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lblQuantity.Location = New System.Drawing.Point(4, 4)
        Me.lblQuantity.Name = "lblQuantity"
        Me.lblQuantity.ReadOnly = True
        Me.lblQuantity.Size = New System.Drawing.Size(75, 23)
        Me.lblQuantity.TabIndex = 0
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(22, 94)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(115, 23)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Qty Available:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(22, 57)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(92, 23)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Book Title:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'panellblTitle
        '
        Me.panellblTitle.BackColor = System.Drawing.Color.White
        Me.panellblTitle.Controls.Add(Me.lblTitle)
        Me.panellblTitle.Location = New System.Drawing.Point(144, 53)
        Me.panellblTitle.Name = "panellblTitle"
        Me.panellblTitle.Padding = New System.Windows.Forms.Padding(1)
        Me.panellblTitle.Size = New System.Drawing.Size(501, 31)
        Me.panellblTitle.TabIndex = 9
        '
        'lblTitle
        '
        Me.lblTitle.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblTitle.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lblTitle.Location = New System.Drawing.Point(4, 4)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.ReadOnly = True
        Me.lblTitle.Size = New System.Drawing.Size(493, 23)
        Me.lblTitle.TabIndex = 0
        '
        'btnSearch
        '
        Me.btnSearch.ActiveBorderThickness = 1
        Me.btnSearch.ActiveCornerRadius = 20
        Me.btnSearch.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnSearch.ActiveForecolor = System.Drawing.Color.White
        Me.btnSearch.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnSearch.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnSearch.BackgroundImage = CType(resources.GetObject("btnSearch.BackgroundImage"), System.Drawing.Image)
        Me.btnSearch.ButtonText = "Search"
        Me.btnSearch.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSearch.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSearch.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSearch.IdleBorderThickness = 1
        Me.btnSearch.IdleCornerRadius = 20
        Me.btnSearch.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSearch.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.btnSearch.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSearch.Location = New System.Drawing.Point(315, 16)
        Me.btnSearch.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(97, 44)
        Me.btnSearch.TabIndex = 10
        Me.btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(36, 28)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(78, 23)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Book ID:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'paneltxtBookID2
        '
        Me.paneltxtBookID2.BackColor = System.Drawing.Color.White
        Me.paneltxtBookID2.Controls.Add(Me.txtBookID2)
        Me.paneltxtBookID2.Location = New System.Drawing.Point(120, 24)
        Me.paneltxtBookID2.Name = "paneltxtBookID2"
        Me.paneltxtBookID2.Padding = New System.Windows.Forms.Padding(1)
        Me.paneltxtBookID2.Size = New System.Drawing.Size(147, 31)
        Me.paneltxtBookID2.TabIndex = 9
        '
        'txtBookID2
        '
        Me.txtBookID2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtBookID2.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.BorrowedBookDataTableBindingSource, "BookID", True))
        Me.txtBookID2.Dock = System.Windows.Forms.DockStyle.Top
        Me.txtBookID2.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBookID2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtBookID2.Location = New System.Drawing.Point(4, 4)
        Me.txtBookID2.Name = "txtBookID2"
        Me.txtBookID2.Size = New System.Drawing.Size(139, 23)
        Me.txtBookID2.TabIndex = 0
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(327, 256)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(140, 23)
        Me.Label6.TabIndex = 18
        Me.Label6.Text = "Quantity Return:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnReturn2
        '
        Me.btnReturn2.ActiveBorderThickness = 1
        Me.btnReturn2.ActiveCornerRadius = 20
        Me.btnReturn2.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnReturn2.ActiveForecolor = System.Drawing.Color.White
        Me.btnReturn2.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnReturn2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnReturn2.BackgroundImage = CType(resources.GetObject("btnReturn2.BackgroundImage"), System.Drawing.Image)
        Me.btnReturn2.ButtonText = "Return"
        Me.btnReturn2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnReturn2.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReturn2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnReturn2.IdleBorderThickness = 1
        Me.btnReturn2.IdleCornerRadius = 20
        Me.btnReturn2.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnReturn2.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.btnReturn2.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnReturn2.Location = New System.Drawing.Point(588, 244)
        Me.btnReturn2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnReturn2.Name = "btnReturn2"
        Me.btnReturn2.Size = New System.Drawing.Size(97, 44)
        Me.btnReturn2.TabIndex = 21
        Me.btnReturn2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'panelReturn
        '
        Me.panelReturn.BackgroundImage = CType(resources.GetObject("panelReturn.BackgroundImage"), System.Drawing.Image)
        Me.panelReturn.Controls.Add(Me.btnDisplayAll2)
        Me.panelReturn.Controls.Add(Me.viewBorrowedBook)
        Me.panelReturn.Controls.Add(Me.chkAccident)
        Me.panelReturn.Controls.Add(Me.Label19)
        Me.panelReturn.Controls.Add(Me.Label18)
        Me.panelReturn.Controls.Add(Me.panelUnexpectedSituation)
        Me.panelReturn.Controls.Add(Me.cmbQtyReturn)
        Me.panelReturn.Controls.Add(Me.btnReturn2)
        Me.panelReturn.Controls.Add(Me.Label6)
        Me.panelReturn.Controls.Add(Me.paneltxtBookID2)
        Me.panelReturn.Controls.Add(Me.Label5)
        Me.panelReturn.Controls.Add(Me.btnSearch)
        Me.panelReturn.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.panelReturn.Location = New System.Drawing.Point(239, 35)
        Me.panelReturn.Name = "panelReturn"
        Me.panelReturn.Size = New System.Drawing.Size(727, 465)
        Me.panelReturn.TabIndex = 19
        '
        'btnDisplayAll2
        '
        Me.btnDisplayAll2.ActiveBorderThickness = 1
        Me.btnDisplayAll2.ActiveCornerRadius = 20
        Me.btnDisplayAll2.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnDisplayAll2.ActiveForecolor = System.Drawing.Color.White
        Me.btnDisplayAll2.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnDisplayAll2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnDisplayAll2.BackgroundImage = CType(resources.GetObject("btnDisplayAll2.BackgroundImage"), System.Drawing.Image)
        Me.btnDisplayAll2.ButtonText = "Display All"
        Me.btnDisplayAll2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDisplayAll2.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDisplayAll2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnDisplayAll2.IdleBorderThickness = 1
        Me.btnDisplayAll2.IdleCornerRadius = 20
        Me.btnDisplayAll2.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnDisplayAll2.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.btnDisplayAll2.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnDisplayAll2.Location = New System.Drawing.Point(540, 16)
        Me.btnDisplayAll2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnDisplayAll2.Name = "btnDisplayAll2"
        Me.btnDisplayAll2.Size = New System.Drawing.Size(130, 44)
        Me.btnDisplayAll2.TabIndex = 28
        Me.btnDisplayAll2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'chkAccident
        '
        Me.chkAccident.AutoSize = True
        Me.chkAccident.Location = New System.Drawing.Point(40, 295)
        Me.chkAccident.Name = "chkAccident"
        Me.chkAccident.Size = New System.Drawing.Size(163, 27)
        Me.chkAccident.TabIndex = 27
        Me.chkAccident.Text = "Accident on Book"
        Me.chkAccident.UseVisualStyleBackColor = True
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label19.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(91, Byte), Integer), CType(CType(83, Byte), Integer))
        Me.Label19.Location = New System.Drawing.Point(436, 414)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(197, 23)
        Me.Label19.TabIndex = 26
        Me.Label19.Text = "*This section is NOT compulsory"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label18.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Label18.Image = CType(resources.GetObject("Label18.Image"), System.Drawing.Image)
        Me.Label18.Location = New System.Drawing.Point(65, 324)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(304, 33)
        Me.Label18.TabIndex = 24
        Me.Label18.Text = "Unexpected Book Situation"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'panelUnexpectedSituation
        '
        Me.panelUnexpectedSituation.BackColor = System.Drawing.Color.Transparent
        Me.panelUnexpectedSituation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.panelUnexpectedSituation.Controls.Add(Me.GroupBox1)
        Me.panelUnexpectedSituation.Controls.Add(Me.btnPayFine)
        Me.panelUnexpectedSituation.Enabled = False
        Me.panelUnexpectedSituation.Location = New System.Drawing.Point(39, 345)
        Me.panelUnexpectedSituation.Name = "panelUnexpectedSituation"
        Me.panelUnexpectedSituation.Size = New System.Drawing.Size(384, 91)
        Me.panelUnexpectedSituation.TabIndex = 25
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.rabLost)
        Me.GroupBox1.Controls.Add(Me.rabDamage)
        Me.GroupBox1.Location = New System.Drawing.Point(21, 17)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(183, 50)
        Me.GroupBox1.TabIndex = 24
        Me.GroupBox1.TabStop = False
        '
        'rabLost
        '
        Me.rabLost.AutoSize = True
        Me.rabLost.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rabLost.Location = New System.Drawing.Point(118, 16)
        Me.rabLost.Name = "rabLost"
        Me.rabLost.Size = New System.Drawing.Size(59, 27)
        Me.rabLost.TabIndex = 1
        Me.rabLost.TabStop = True
        Me.rabLost.Text = "Lost"
        Me.rabLost.UseVisualStyleBackColor = True
        '
        'rabDamage
        '
        Me.rabDamage.AutoSize = True
        Me.rabDamage.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rabDamage.Location = New System.Drawing.Point(8, 16)
        Me.rabDamage.Name = "rabDamage"
        Me.rabDamage.Size = New System.Drawing.Size(92, 27)
        Me.rabDamage.TabIndex = 0
        Me.rabDamage.TabStop = True
        Me.rabDamage.Text = "Damage"
        Me.rabDamage.UseVisualStyleBackColor = True
        '
        'btnPayFine
        '
        Me.btnPayFine.ActiveBorderThickness = 1
        Me.btnPayFine.ActiveCornerRadius = 20
        Me.btnPayFine.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnPayFine.ActiveForecolor = System.Drawing.Color.White
        Me.btnPayFine.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnPayFine.BackColor = System.Drawing.Color.Transparent
        Me.btnPayFine.BackgroundImage = CType(resources.GetObject("btnPayFine.BackgroundImage"), System.Drawing.Image)
        Me.btnPayFine.ButtonText = "Pay Fine"
        Me.btnPayFine.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnPayFine.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPayFine.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnPayFine.IdleBorderThickness = 1
        Me.btnPayFine.IdleCornerRadius = 20
        Me.btnPayFine.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnPayFine.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.btnPayFine.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnPayFine.Location = New System.Drawing.Point(234, 24)
        Me.btnPayFine.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnPayFine.Name = "btnPayFine"
        Me.btnPayFine.Size = New System.Drawing.Size(114, 44)
        Me.btnPayFine.TabIndex = 14
        Me.btnPayFine.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmbQtyReturn
        '
        Me.cmbQtyReturn.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbQtyReturn.FormattingEnabled = True
        Me.cmbQtyReturn.Location = New System.Drawing.Point(473, 252)
        Me.cmbQtyReturn.MaxDropDownItems = 20
        Me.cmbQtyReturn.Name = "cmbQtyReturn"
        Me.cmbQtyReturn.Size = New System.Drawing.Size(74, 31)
        Me.cmbQtyReturn.TabIndex = 22
        '
        'panelFine
        '
        Me.panelFine.BackgroundImage = CType(resources.GetObject("panelFine.BackgroundImage"), System.Drawing.Image)
        Me.panelFine.Controls.Add(Me.viewFine)
        Me.panelFine.Controls.Add(Me.btnDisplayAll)
        Me.panelFine.Controls.Add(Me.btnSave)
        Me.panelFine.Controls.Add(Me.FlowLayoutPanel9)
        Me.panelFine.Controls.Add(Me.Label12)
        Me.panelFine.Controls.Add(Me.btnSearch2)
        Me.panelFine.Controls.Add(Me.Label13)
        Me.panelFine.Controls.Add(Me.Panel6)
        Me.panelFine.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.panelFine.Location = New System.Drawing.Point(239, 35)
        Me.panelFine.Name = "panelFine"
        Me.panelFine.Size = New System.Drawing.Size(727, 465)
        Me.panelFine.TabIndex = 20
        '
        'viewFine
        '
        DataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.viewFine.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle9
        Me.viewFine.AutoGenerateColumns = False
        Me.viewFine.BackgroundColor = System.Drawing.Color.Gainsboro
        Me.viewFine.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.viewFine.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(CType(CType(49, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(57, Byte), Integer))
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(245, Byte), Integer))
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.viewFine.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.viewFine.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.viewFine.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.StudentIDDataGridViewTextBoxColumn1, Me.StudentNameDataGridViewTextBoxColumn1, Me.BookIDDataGridViewTextBoxColumn1, Me.BookTitleDataGridViewTextBoxColumn1, Me.ReturnDateDataGridViewTextBoxColumn1, Me.ReasonDataGridViewTextBoxColumn, Me.FineChargedDataGridViewTextBoxColumn, Me.PayStatusDataGridViewTextBoxColumn, Me.QuantityDataGridViewTextBoxColumn})
        Me.viewFine.DataSource = Me.FinePaymentDataTableBindingSource
        Me.viewFine.DoubleBuffered = True
        Me.viewFine.EnableHeadersVisualStyles = False
        Me.viewFine.HeaderBgColor = System.Drawing.Color.FromArgb(CType(CType(49, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.viewFine.HeaderForeColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(245, Byte), Integer))
        Me.viewFine.Location = New System.Drawing.Point(40, 34)
        Me.viewFine.Name = "viewFine"
        Me.viewFine.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.viewFine.Size = New System.Drawing.Size(645, 145)
        Me.viewFine.TabIndex = 22
        '
        'StudentIDDataGridViewTextBoxColumn1
        '
        Me.StudentIDDataGridViewTextBoxColumn1.DataPropertyName = "StudentID"
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.StudentIDDataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle11
        Me.StudentIDDataGridViewTextBoxColumn1.HeaderText = "Student_ID"
        Me.StudentIDDataGridViewTextBoxColumn1.Name = "StudentIDDataGridViewTextBoxColumn1"
        Me.StudentIDDataGridViewTextBoxColumn1.ReadOnly = True
        Me.StudentIDDataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.StudentIDDataGridViewTextBoxColumn1.Width = 92
        '
        'StudentNameDataGridViewTextBoxColumn1
        '
        Me.StudentNameDataGridViewTextBoxColumn1.DataPropertyName = "StudentName"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.StudentNameDataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle12
        Me.StudentNameDataGridViewTextBoxColumn1.HeaderText = "        Student_Name"
        Me.StudentNameDataGridViewTextBoxColumn1.Name = "StudentNameDataGridViewTextBoxColumn1"
        Me.StudentNameDataGridViewTextBoxColumn1.ReadOnly = True
        Me.StudentNameDataGridViewTextBoxColumn1.Width = 200
        '
        'BookIDDataGridViewTextBoxColumn1
        '
        Me.BookIDDataGridViewTextBoxColumn1.DataPropertyName = "BookID"
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BookIDDataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle13
        Me.BookIDDataGridViewTextBoxColumn1.HeaderText = "Book_ID"
        Me.BookIDDataGridViewTextBoxColumn1.Name = "BookIDDataGridViewTextBoxColumn1"
        Me.BookIDDataGridViewTextBoxColumn1.ReadOnly = True
        Me.BookIDDataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.BookIDDataGridViewTextBoxColumn1.Width = 74
        '
        'BookTitleDataGridViewTextBoxColumn1
        '
        Me.BookTitleDataGridViewTextBoxColumn1.DataPropertyName = "BookTitle"
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BookTitleDataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle14
        Me.BookTitleDataGridViewTextBoxColumn1.HeaderText = "           Book_Title"
        Me.BookTitleDataGridViewTextBoxColumn1.Name = "BookTitleDataGridViewTextBoxColumn1"
        Me.BookTitleDataGridViewTextBoxColumn1.ReadOnly = True
        Me.BookTitleDataGridViewTextBoxColumn1.Width = 200
        '
        'ReturnDateDataGridViewTextBoxColumn1
        '
        Me.ReturnDateDataGridViewTextBoxColumn1.DataPropertyName = "ReturnDate"
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ReturnDateDataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle15
        Me.ReturnDateDataGridViewTextBoxColumn1.HeaderText = "Return_Date"
        Me.ReturnDateDataGridViewTextBoxColumn1.Name = "ReturnDateDataGridViewTextBoxColumn1"
        Me.ReturnDateDataGridViewTextBoxColumn1.ReadOnly = True
        Me.ReturnDateDataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.ReturnDateDataGridViewTextBoxColumn1.Width = 106
        '
        'ReasonDataGridViewTextBoxColumn
        '
        Me.ReasonDataGridViewTextBoxColumn.DataPropertyName = "Reason"
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ReasonDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle16
        Me.ReasonDataGridViewTextBoxColumn.HeaderText = "Reason"
        Me.ReasonDataGridViewTextBoxColumn.Name = "ReasonDataGridViewTextBoxColumn"
        Me.ReasonDataGridViewTextBoxColumn.ReadOnly = True
        Me.ReasonDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.ReasonDataGridViewTextBoxColumn.Width = 76
        '
        'FineChargedDataGridViewTextBoxColumn
        '
        Me.FineChargedDataGridViewTextBoxColumn.DataPropertyName = "FineCharged"
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle17.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.FineChargedDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle17
        Me.FineChargedDataGridViewTextBoxColumn.HeaderText = "Fine_Charged"
        Me.FineChargedDataGridViewTextBoxColumn.Name = "FineChargedDataGridViewTextBoxColumn"
        Me.FineChargedDataGridViewTextBoxColumn.ReadOnly = True
        Me.FineChargedDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.FineChargedDataGridViewTextBoxColumn.Width = 115
        '
        'PayStatusDataGridViewTextBoxColumn
        '
        Me.PayStatusDataGridViewTextBoxColumn.DataPropertyName = "PayStatus"
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.PayStatusDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle18
        Me.PayStatusDataGridViewTextBoxColumn.HeaderText = "Pay_Status"
        Me.PayStatusDataGridViewTextBoxColumn.Name = "PayStatusDataGridViewTextBoxColumn"
        Me.PayStatusDataGridViewTextBoxColumn.ReadOnly = True
        Me.PayStatusDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.PayStatusDataGridViewTextBoxColumn.Width = 90
        '
        'QuantityDataGridViewTextBoxColumn
        '
        Me.QuantityDataGridViewTextBoxColumn.DataPropertyName = "Quantity"
        DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle19.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.QuantityDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle19
        Me.QuantityDataGridViewTextBoxColumn.HeaderText = "Quantity"
        Me.QuantityDataGridViewTextBoxColumn.Name = "QuantityDataGridViewTextBoxColumn"
        Me.QuantityDataGridViewTextBoxColumn.ReadOnly = True
        Me.QuantityDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.QuantityDataGridViewTextBoxColumn.Width = 79
        '
        'FinePaymentDataTableBindingSource
        '
        Me.FinePaymentDataTableBindingSource.DataSource = GetType(Library_System.TestingDatabase1DataSet.Fine_PaymentDataTable)
        '
        'btnDisplayAll
        '
        Me.btnDisplayAll.ActiveBorderThickness = 1
        Me.btnDisplayAll.ActiveCornerRadius = 20
        Me.btnDisplayAll.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnDisplayAll.ActiveForecolor = System.Drawing.Color.White
        Me.btnDisplayAll.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnDisplayAll.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnDisplayAll.BackgroundImage = CType(resources.GetObject("btnDisplayAll.BackgroundImage"), System.Drawing.Image)
        Me.btnDisplayAll.ButtonText = "Display All"
        Me.btnDisplayAll.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDisplayAll.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDisplayAll.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnDisplayAll.IdleBorderThickness = 1
        Me.btnDisplayAll.IdleCornerRadius = 20
        Me.btnDisplayAll.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnDisplayAll.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.btnDisplayAll.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnDisplayAll.Location = New System.Drawing.Point(537, 194)
        Me.btnDisplayAll.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnDisplayAll.Name = "btnDisplayAll"
        Me.btnDisplayAll.Size = New System.Drawing.Size(130, 44)
        Me.btnDisplayAll.TabIndex = 23
        Me.btnDisplayAll.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnSave
        '
        Me.btnSave.ActiveBorderThickness = 1
        Me.btnSave.ActiveCornerRadius = 20
        Me.btnSave.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnSave.ActiveForecolor = System.Drawing.Color.White
        Me.btnSave.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnSave.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnSave.BackgroundImage = CType(resources.GetObject("btnSave.BackgroundImage"), System.Drawing.Image)
        Me.btnSave.ButtonText = "&Save"
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSave.IdleBorderThickness = 1
        Me.btnSave.IdleCornerRadius = 20
        Me.btnSave.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSave.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.btnSave.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSave.Location = New System.Drawing.Point(619, 386)
        Me.btnSave.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(76, 44)
        Me.btnSave.TabIndex = 20
        Me.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlowLayoutPanel9
        '
        Me.FlowLayoutPanel9.BackColor = System.Drawing.Color.White
        Me.FlowLayoutPanel9.Controls.Add(Me.txtBookID3)
        Me.FlowLayoutPanel9.Location = New System.Drawing.Point(150, 202)
        Me.FlowLayoutPanel9.Name = "FlowLayoutPanel9"
        Me.FlowLayoutPanel9.Padding = New System.Windows.Forms.Padding(1)
        Me.FlowLayoutPanel9.Size = New System.Drawing.Size(147, 31)
        Me.FlowLayoutPanel9.TabIndex = 18
        '
        'txtBookID3
        '
        Me.txtBookID3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtBookID3.Dock = System.Windows.Forms.DockStyle.Top
        Me.txtBookID3.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBookID3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtBookID3.Location = New System.Drawing.Point(4, 4)
        Me.txtBookID3.Name = "txtBookID3"
        Me.txtBookID3.Size = New System.Drawing.Size(139, 23)
        Me.txtBookID3.TabIndex = 0
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(66, 206)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(78, 23)
        Me.Label12.TabIndex = 17
        Me.Label12.Text = "Book ID:"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnSearch2
        '
        Me.btnSearch2.ActiveBorderThickness = 1
        Me.btnSearch2.ActiveCornerRadius = 20
        Me.btnSearch2.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnSearch2.ActiveForecolor = System.Drawing.Color.White
        Me.btnSearch2.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnSearch2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnSearch2.BackgroundImage = CType(resources.GetObject("btnSearch2.BackgroundImage"), System.Drawing.Image)
        Me.btnSearch2.ButtonText = "Search"
        Me.btnSearch2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSearch2.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSearch2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSearch2.IdleBorderThickness = 1
        Me.btnSearch2.IdleCornerRadius = 20
        Me.btnSearch2.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSearch2.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.btnSearch2.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSearch2.Location = New System.Drawing.Point(324, 194)
        Me.btnSearch2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnSearch2.Name = "btnSearch2"
        Me.btnSearch2.Size = New System.Drawing.Size(97, 44)
        Me.btnSearch2.TabIndex = 19
        Me.btnSearch2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label13.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Label13.Image = CType(resources.GetObject("Label13.Image"), System.Drawing.Image)
        Me.Label13.Location = New System.Drawing.Point(429, 255)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(125, 33)
        Me.Label13.TabIndex = 15
        Me.Label13.Text = "Payment"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.Transparent
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel6.Controls.Add(Me.Label20)
        Me.Panel6.Controls.Add(Me.btnCharge)
        Me.Panel6.Controls.Add(Me.FlowLayoutPanel5)
        Me.Panel6.Controls.Add(Me.Label14)
        Me.Panel6.Controls.Add(Me.Label15)
        Me.Panel6.Controls.Add(Me.FlowLayoutPanel6)
        Me.Panel6.Controls.Add(Me.FlowLayoutPanel7)
        Me.Panel6.Controls.Add(Me.Label16)
        Me.Panel6.Controls.Add(Me.Label17)
        Me.Panel6.Controls.Add(Me.FlowLayoutPanel8)
        Me.Panel6.Location = New System.Drawing.Point(32, 276)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(559, 153)
        Me.Panel6.TabIndex = 16
        '
        'Label20
        '
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(150, 101)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(35, 23)
        Me.Label20.TabIndex = 15
        Me.Label20.Text = "RM"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnCharge
        '
        Me.btnCharge.ActiveBorderThickness = 1
        Me.btnCharge.ActiveCornerRadius = 20
        Me.btnCharge.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnCharge.ActiveForecolor = System.Drawing.Color.White
        Me.btnCharge.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnCharge.BackColor = System.Drawing.Color.Transparent
        Me.btnCharge.BackgroundImage = CType(resources.GetObject("btnCharge.BackgroundImage"), System.Drawing.Image)
        Me.btnCharge.ButtonText = "Change"
        Me.btnCharge.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCharge.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCharge.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnCharge.IdleBorderThickness = 1
        Me.btnCharge.IdleCornerRadius = 20
        Me.btnCharge.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnCharge.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.btnCharge.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnCharge.Location = New System.Drawing.Point(334, 32)
        Me.btnCharge.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnCharge.Name = "btnCharge"
        Me.btnCharge.Size = New System.Drawing.Size(114, 44)
        Me.btnCharge.TabIndex = 14
        Me.btnCharge.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlowLayoutPanel5
        '
        Me.FlowLayoutPanel5.BackColor = System.Drawing.Color.White
        Me.FlowLayoutPanel5.Controls.Add(Me.lblFine)
        Me.FlowLayoutPanel5.Location = New System.Drawing.Point(154, 57)
        Me.FlowLayoutPanel5.Name = "FlowLayoutPanel5"
        Me.FlowLayoutPanel5.Padding = New System.Windows.Forms.Padding(1)
        Me.FlowLayoutPanel5.Size = New System.Drawing.Size(135, 31)
        Me.FlowLayoutPanel5.TabIndex = 13
        '
        'lblFine
        '
        Me.lblFine.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblFine.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblFine.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblFine.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblFine.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFine.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lblFine.Location = New System.Drawing.Point(4, 4)
        Me.lblFine.Name = "lblFine"
        Me.lblFine.ReadOnly = True
        Me.lblFine.Size = New System.Drawing.Size(127, 23)
        Me.lblFine.TabIndex = 0
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(15, 60)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(132, 23)
        Me.Label14.TabIndex = 12
        Me.Label14.Text = "Total Fine:"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(15, 22)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(132, 23)
        Me.Label15.TabIndex = 2
        Me.Label15.Text = "Overdue Day(s):"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'FlowLayoutPanel6
        '
        Me.FlowLayoutPanel6.BackColor = System.Drawing.Color.White
        Me.FlowLayoutPanel6.Controls.Add(Me.lblChange)
        Me.FlowLayoutPanel6.Location = New System.Drawing.Point(395, 98)
        Me.FlowLayoutPanel6.Name = "FlowLayoutPanel6"
        Me.FlowLayoutPanel6.Padding = New System.Windows.Forms.Padding(1)
        Me.FlowLayoutPanel6.Size = New System.Drawing.Size(136, 31)
        Me.FlowLayoutPanel6.TabIndex = 11
        '
        'lblChange
        '
        Me.lblChange.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblChange.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblChange.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblChange.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblChange.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChange.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lblChange.Location = New System.Drawing.Point(4, 4)
        Me.lblChange.Name = "lblChange"
        Me.lblChange.ReadOnly = True
        Me.lblChange.Size = New System.Drawing.Size(128, 23)
        Me.lblChange.TabIndex = 0
        '
        'FlowLayoutPanel7
        '
        Me.FlowLayoutPanel7.BackColor = System.Drawing.Color.White
        Me.FlowLayoutPanel7.Controls.Add(Me.lblOverdueDay)
        Me.FlowLayoutPanel7.Location = New System.Drawing.Point(153, 18)
        Me.FlowLayoutPanel7.Name = "FlowLayoutPanel7"
        Me.FlowLayoutPanel7.Padding = New System.Windows.Forms.Padding(1)
        Me.FlowLayoutPanel7.Size = New System.Drawing.Size(136, 31)
        Me.FlowLayoutPanel7.TabIndex = 5
        '
        'lblOverdueDay
        '
        Me.lblOverdueDay.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblOverdueDay.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lblOverdueDay.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblOverdueDay.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOverdueDay.ForeColor = System.Drawing.Color.Black
        Me.lblOverdueDay.Location = New System.Drawing.Point(4, 4)
        Me.lblOverdueDay.Name = "lblOverdueDay"
        Me.lblOverdueDay.ReadOnly = True
        Me.lblOverdueDay.Size = New System.Drawing.Size(128, 23)
        Me.lblOverdueDay.TabIndex = 0
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(312, 101)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(75, 23)
        Me.Label16.TabIndex = 10
        Me.Label16.Text = "Change:"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(16, 101)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(131, 23)
        Me.Label17.TabIndex = 8
        Me.Label17.Text = "Cash:"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'FlowLayoutPanel8
        '
        Me.FlowLayoutPanel8.BackColor = System.Drawing.Color.White
        Me.FlowLayoutPanel8.Controls.Add(Me.txtCash)
        Me.FlowLayoutPanel8.Location = New System.Drawing.Point(185, 97)
        Me.FlowLayoutPanel8.Name = "FlowLayoutPanel8"
        Me.FlowLayoutPanel8.Padding = New System.Windows.Forms.Padding(1)
        Me.FlowLayoutPanel8.Size = New System.Drawing.Size(105, 31)
        Me.FlowLayoutPanel8.TabIndex = 9
        '
        'txtCash
        '
        Me.txtCash.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txtCash.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtCash.Cursor = System.Windows.Forms.Cursors.Default
        Me.txtCash.Dock = System.Windows.Forms.DockStyle.Top
        Me.txtCash.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCash.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCash.Location = New System.Drawing.Point(4, 4)
        Me.txtCash.Name = "txtCash"
        Me.txtCash.Size = New System.Drawing.Size(97, 23)
        Me.txtCash.TabIndex = 0
        '
        'frmTransaction
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 21.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(966, 500)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.panelBorrow)
        Me.Controls.Add(Me.panelReturn)
        Me.Controls.Add(Me.panelFine)
        Me.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(5)
        Me.Name = "frmTransaction"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Transaction"
        Me.ToolTip2.SetToolTip(Me, "Click to close")
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        CType(Me.picBack, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.viewBorrowedBook, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BorrowedBookDataTableBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.panelBorrow.ResumeLayout(False)
        Me.panelStudentDetails.ResumeLayout(False)
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.FlowLayoutPanel1.PerformLayout()
        Me.FlowLayoutPanel2.ResumeLayout(False)
        Me.FlowLayoutPanel2.PerformLayout()
        Me.FlowLayoutPanel3.ResumeLayout(False)
        Me.FlowLayoutPanel3.PerformLayout()
        Me.panelBookDetails.ResumeLayout(False)
        Me.paneltxtBookID.ResumeLayout(False)
        Me.paneltxtBookID.PerformLayout()
        Me.paneltxtQuantity.ResumeLayout(False)
        Me.paneltxtQuantity.PerformLayout()
        Me.panellblTitle.ResumeLayout(False)
        Me.panellblTitle.PerformLayout()
        Me.paneltxtBookID2.ResumeLayout(False)
        Me.paneltxtBookID2.PerformLayout()
        Me.panelReturn.ResumeLayout(False)
        Me.panelReturn.PerformLayout()
        Me.panelUnexpectedSituation.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.panelFine.ResumeLayout(False)
        CType(Me.viewFine, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FinePaymentDataTableBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FlowLayoutPanel9.ResumeLayout(False)
        Me.FlowLayoutPanel9.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.FlowLayoutPanel5.ResumeLayout(False)
        Me.FlowLayoutPanel5.PerformLayout()
        Me.FlowLayoutPanel6.ResumeLayout(False)
        Me.FlowLayoutPanel6.PerformLayout()
        Me.FlowLayoutPanel7.ResumeLayout(False)
        Me.FlowLayoutPanel7.PerformLayout()
        Me.FlowLayoutPanel8.ResumeLayout(False)
        Me.FlowLayoutPanel8.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents pnlLeftBorrow As FlowLayoutPanel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnBorrow As Button
    Friend WithEvents lblClose As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents pnlLeftFine As FlowLayoutPanel
    Friend WithEvents pnlLeftReturn As FlowLayoutPanel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents btnFine As Button
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents btnReturn As Button
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents BunifuElipse1 As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents btnCheckBook As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents panelBorrow As Panel
    Friend WithEvents paneltxtQuantity As FlowLayoutPanel
    Friend WithEvents lblQuantity As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents panellblTitle As FlowLayoutPanel
    Friend WithEvents lblTitle As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents paneltxtBookID As FlowLayoutPanel
    Friend WithEvents txtBookID As TextBox
    Friend WithEvents panelBookDetails As Panel
    Friend WithEvents lblBookDetails As Label
    Friend WithEvents btnConfirm As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents lblStudentDetails As Label
    Friend WithEvents panelStudentDetails As Panel
    Friend WithEvents Label7 As Label
    Friend WithEvents btnCheckStud As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents lblIC As TextBox
    Friend WithEvents FlowLayoutPanel2 As FlowLayoutPanel
    Friend WithEvents txtStudID As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents FlowLayoutPanel3 As FlowLayoutPanel
    Friend WithEvents lblStudName As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents picBack As PictureBox
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents ToolTip2 As ToolTip
    Friend WithEvents panelReturn As Panel
    Friend WithEvents btnReturn2 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents Label6 As Label
    Friend WithEvents paneltxtBookID2 As FlowLayoutPanel
    Friend WithEvents txtBookID2 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents btnSearch As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents panelFine As Panel
    Friend WithEvents btnSave As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents FlowLayoutPanel9 As FlowLayoutPanel
    Friend WithEvents txtBookID3 As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents btnSearch2 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents Label13 As Label
    Friend WithEvents Panel6 As Panel
    Friend WithEvents btnCharge As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents FlowLayoutPanel5 As FlowLayoutPanel
    Friend WithEvents lblFine As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents FlowLayoutPanel6 As FlowLayoutPanel
    Friend WithEvents lblChange As TextBox
    Friend WithEvents FlowLayoutPanel7 As FlowLayoutPanel
    Friend WithEvents lblOverdueDay As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents FlowLayoutPanel8 As FlowLayoutPanel
    Friend WithEvents txtCash As TextBox
    Friend WithEvents cmbQtyBorrow As ComboBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents panelUnexpectedSituation As Panel
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents rabLost As RadioButton
    Friend WithEvents rabDamage As RadioButton
    Friend WithEvents btnPayFine As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents cmbQtyReturn As ComboBox
    Friend WithEvents BorrowedBookDataTableBindingSource As BindingSource
    Friend WithEvents chkAccident As CheckBox
    Friend WithEvents viewBorrowedBook As Bunifu.Framework.UI.BunifuCustomDataGrid
    Friend WithEvents viewFine As Bunifu.Framework.UI.BunifuCustomDataGrid
    Friend WithEvents btnDisplayAll As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents Label20 As Label
    Friend WithEvents btnDisplayAll2 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents FinePaymentDataTableBindingSource As BindingSource
    Friend WithEvents QuantityBorrowDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BookIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BookTitleDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StudentIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StudentNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents QuantityBorrow As DataGridViewTextBoxColumn
    Friend WithEvents ReturnDateDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StudentIDDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents StudentNameDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents BookIDDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents BookTitleDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents ReturnDateDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents ReasonDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents FineChargedDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PayStatusDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents QuantityDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
