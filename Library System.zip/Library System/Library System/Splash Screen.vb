﻿Imports System.Data.SqlClient

'code completed

Public Class frmSplashScreen
    Private Structure OverdueBookData
        Dim strBookID As String
        Dim strBookTitle As String
        Dim strStudID As String
        Dim strStudName As String
        Dim intQtyBorrow As Integer
        Dim returnDate As Date
    End Structure

    Private Structure BlackListStudent
        Dim strStudID As String
        Dim strStudName As String
        Dim dblCharged As Double
        Dim intQuantity As Integer
    End Structure

    Dim overdue As OverdueBookData
    Dim blacklist As BlackListStudent

    Dim connection As New SqlConnection("Data Source =  (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\Sim Ka Yee\Documents\Tarc\Diploma\Year 2 Sem 2\Windows Application Programming\Library System\Library System\TestingDatabase1.mdf; Integrated Security = true")
    Dim currentDate As Date = Format(Date.Now, "dd/MM/yyyy")

    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        End
    End Sub

    Private Sub frmSplashScreen_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'automatically add overdue book into fine_payment database
        Dim command As New SqlCommand("Select * From Borrowed_Book
                                       Where ReturnDate < @date", connection)
        command.Parameters.AddWithValue("@date", currentDate)

        Dim adapter As New SqlDataAdapter(command)
        Dim table As New DataTable
        adapter.Fill(table)

        connection.Open()
        If table.Rows.Count() > 0 Then
            For i = 0 To table.Rows.Count() - 1 Step 1

                overdue.strBookID = table.Rows(i)(0).ToString()
                overdue.strBookTitle = table.Rows(i)(1).ToString()
                overdue.strStudID = table.Rows(i)(2).ToString()
                overdue.strStudName = table.Rows(i)(3).ToString()
                overdue.intQtyBorrow = table.Rows(i)(4)
                overdue.returnDate = table.Rows(i)(5)

                Dim span = currentDate - overdue.returnDate
                Dim dayDiff As Integer = span.TotalDays

                Dim command1 As New SqlCommand("INSERT INTO Fine_Payment VALUES
                                                (@studID, @studName, @bookID, @bookTitle, @date, @reason, @fine, @status, @qty) ", connection)
                command1.Parameters.AddWithValue("@studID", overdue.strStudID)
                command1.Parameters.AddWithValue("@studName", overdue.strStudName)
                command1.Parameters.AddWithValue("@bookID", overdue.strBookID)
                command1.Parameters.AddWithValue("@bookTitle", overdue.strBookTitle)
                command1.Parameters.AddWithValue("@date", overdue.returnDate)
                command1.Parameters.AddWithValue("@reason", "Overdue")
                command1.Parameters.AddWithValue("@fine", 0.5 * dayDiff * overdue.intQtyBorrow)
                command1.Parameters.AddWithValue("@status", "Unpay")
                command1.Parameters.AddWithValue("@qty", overdue.intQtyBorrow)

                command1.ExecuteNonQuery()
            Next
            Dim command2 As New SqlCommand("DELETE FROM Borrowed_Book
                                            Where ReturnDate < @date", connection)
            command2.Parameters.AddWithValue("@date", currentDate)

            command2.ExecuteNonQuery()
        End If

        'automatically add blacklist student
        Dim command3 As New SqlCommand("SELECT StudentID, StudentName, Sum(FineCharged), Sum(Quantity) 
                                        FROM Fine_Payment
                                        GROUP BY StudentID, StudentName
                                        HAVING Sum(Quantity) >= 5", connection)

        Dim adapter1 As New SqlDataAdapter(command3)
        Dim table1 As New DataTable
        adapter1.Fill(table1)

        If table1.Rows.Count() > 0 Then
            For i = 0 To table1.Rows.Count() - 1 Step 1
                blacklist.strStudID = table1.Rows(i)(0).ToString()
                blacklist.strStudName = table1.Rows(i)(1).ToString()
                blacklist.dblCharged = table1.Rows(i)(2)
                blacklist.intQuantity = table1.Rows(i)(3)

                Dim command4 As New SqlCommand("SELECT StudentID FROM Fine_Payment WHERE StudentID = @id", connection)
                command4.Parameters.AddWithValue("@id", blacklist.strStudID)
                Dim adapter2 As New SqlDataAdapter(command4)
                Dim table2 As New DataTable
                adapter2.Fill(table2)
                If table1.Rows.Count() = 0 Then
                    Dim command5 As New SqlCommand("INSERT INTO BlackList VALUES
                                                (@studID, @studName, @number, @total, @date) ", connection)
                    command5.Parameters.AddWithValue("@studID", blacklist.strStudID)
                    command5.Parameters.AddWithValue("@studName", blacklist.strStudName)
                    command5.Parameters.AddWithValue("@number", blacklist.intQuantity)
                    command5.Parameters.AddWithValue("@total", blacklist.dblCharged)
                    command5.Parameters.AddWithValue("@date", currentDate)

                    command5.ExecuteNonQuery()
                End If
            Next
        End If

        'Dim command6 As New SqlCommand("DELETE FROM fine_payment", connection)
        'command6.ExecuteNonQuery()

        connection.Close()
    End Sub
End Class