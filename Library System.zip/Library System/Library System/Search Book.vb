﻿Imports System.Data.SqlClient

Public Class frmSearchBook
    Dim connection As New SqlConnection("Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\Sim Ka Yee\Documents\Tarc\Diploma\Year 2 Sem 2\Windows Application Programming\Library System\Library System\TestingDatabase1.mdf; Integrated Security = true")

    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        End
    End Sub

    Private Sub displayAllBook(view As DataGridView)
        Dim command As New SqlCommand("Select * From book", connection)
        connection.Open()
        Dim adapter As New SqlDataAdapter(command)
        Dim table As New DataTable
        adapter.Fill(table)
        view.DataSource = table
        connection.Close()
    End Sub

    Private Sub btnBookID_Click(sender As Object, e As EventArgs) Handles btnBookID.Click
        pnlLeftID.Visible = True
        pnlLeftTitle.Visible = False
        pnlLeftLanguage.Visible = False

        panelBookID.Visible = True
        panelBookTitle.Visible = False
        panelLanguage.Visible = False

        displayAllBook(viewBook1)
    End Sub

    Private Sub btnBookTitle_Click(sender As Object, e As EventArgs) Handles btnBookTitle.Click
        pnlLeftID.Visible = False
        pnlLeftTitle.Visible = True
        pnlLeftLanguage.Visible = False

        panelBookID.Visible = False
        panelBookTitle.Visible = True
        panelLanguage.Visible = False

        displayAllBook(viewBook2)
    End Sub

    Private Sub btnLanguage_Click(sender As Object, e As EventArgs) Handles btnLanguage.Click
        pnlLeftID.Visible = False
        pnlLeftTitle.Visible = False
        pnlLeftLanguage.Visible = True

        panelBookID.Visible = False
        panelBookTitle.Visible = False
        panelLanguage.Visible = True

        displayAllBook(viewBook3)
    End Sub

    Private Sub frmSearchBook_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        pnlLeftID.Visible = True
        pnlLeftTitle.Visible = False
        pnlLeftLanguage.Visible = False
        panelBookID.Visible = True
        panelBookTitle.Visible = False
        panelLanguage.Visible = False

        txtSearchBookID.Focus()

        displayAllBook(viewBook1)

        btnSearch1.BackColor = Color.Transparent
        btnSearch2.BackColor = Color.Transparent
        btnSearch3.BackColor = Color.Transparent
        btnDisplayAll1.BackColor = Color.Transparent
        btnDisplayAll2.BackColor = Color.Transparent
        btnDisplayAll3.BackColor = Color.Transparent
    End Sub

    Private Sub searchButton(str As String, search As String, view As DataGridView)
        Dim command As New SqlCommand(search, connection)
        command.Parameters.AddWithValue("@book", str)
        connection.Open()
        Dim adapter As New SqlDataAdapter(command)
        Dim table As New DataTable
        adapter.Fill(table)

        If table.Rows.Count() > 0 Then
            view.DataSource = table
        Else
            MessageBox.Show("No Book Data Found.", "TARC Library", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            For i = view.Rows.Count - 2 To 0 Step -1
                view.Rows.RemoveAt(i)
            Next
            txtSearchBookID.SelectAll()
        End If
        connection.Close()
    End Sub

    Private Sub btnSearch1_Click(sender As Object, e As EventArgs) Handles btnSearch1.Click
        Dim search As String = "Select * From Book Where BookID = @book"
        searchButton(txtSearchBookID.Text, search, viewBook1)
    End Sub

    Private Sub btnDisplayAll1_Click(sender As Object, e As EventArgs) Handles btnDisplayAll1.Click
        displayAllBook(viewBook1)
    End Sub

    Private Sub btnSearch3_Click(sender As Object, e As EventArgs) Handles btnSearch3.Click
        Dim search As String = "Select * From Book Where Language = @book"
        searchButton(cmbLanguage.SelectedItem, search, viewBook3)
    End Sub

    Private Sub btnDisplayAll3_Click(sender As Object, e As EventArgs) Handles btnDisplayAll3.Click
        displayAllBook(viewBook3)
    End Sub

    Private Sub picBack_Click(sender As Object, e As EventArgs) Handles picBack.Click
        Me.Hide()
        frmStudentAction.Show()
    End Sub

    Private Sub btnSearch2_Click(sender As Object, e As EventArgs) Handles btnSearch2.Click
        Dim search As String = "Select * From Book Where BookTitle = @book"
        searchButton(txtSearchBookTitle.Text, search, viewBook2)
    End Sub

    Private Sub btnDisplayAll2_Click(sender As Object, e As EventArgs) Handles btnDisplayAll2.Click
        displayAllBook(viewBook2)
    End Sub
End Class