﻿Partial Class TestingDatabase1DataSet
End Class

Namespace TestingDatabase1DataSetTableAdapters

    Partial Public Class BookTableAdapter
    End Class
End Namespace
