﻿Imports System.Data.SqlClient

'code and interface all complete but need to take student id from login module

Public Class frmHistory
    Dim connection As New SqlConnection("Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\Sim Ka Yee\Documents\Tarc\Diploma\Year 2 Sem 2\Windows Application Programming\Library System\Library System\TestingDatabase1.mdf; Integrated Security = true")

    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        End
    End Sub

    Private Sub searchButton(str As String, search As String, view As DataGridView)
        Dim command As New SqlCommand(search, connection)
        command.Parameters.AddWithValue("@book", str)
        connection.Open()
        Dim adapter As New SqlDataAdapter(command)
        Dim table As New DataTable
        adapter.Fill(table)

        If table.Rows.Count() > 0 Then
            view.DataSource = table
        Else
            MessageBox.Show("No Data Found.", "TARC Library", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            For i = view.Rows.Count - 2 To 0 Step -1
                view.Rows.RemoveAt(i)
            Next
            txtSearchBookID.SelectAll()
        End If
        connection.Close()
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Dim search As String = "Select * From Borrowed_Book Where BookID = @book"
        searchButton(txtSearchBookID.Text, search, viewBorrowedBook)
    End Sub

    Private Sub btnDisplayAll_Click(sender As Object, e As EventArgs) Handles btnDisplayAll.Click
        Dim command As New SqlCommand("Select * From Borrowed_Book", connection)
        connection.Open()
        Dim adapter As New SqlDataAdapter(command)
        Dim table As New DataTable
        adapter.Fill(table)
        viewBorrowedBook.DataSource = table
        connection.Close()
    End Sub

    Private Sub btnBorrowedBook_Click(sender As Object, e As EventArgs) Handles btnBorrowedBook.Click
        pnlLeftBorrowedBook.Visible = True
        pnlLeftFineHistory.Visible = False

        panelBorrowedBook.Visible = True
        panelFineHistory.Visible = False

        btnDisplayAll_Click(sender, e)
    End Sub

    Private Sub frmHistory_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        btnBorrowedBook_Click(sender, e)

        btnSearch.BackColor = Color.Transparent
        btnDisplayAll.BackColor = Color.Transparent
        btnSearch2.BackColor = Color.Transparent
        btnDisplayAll2.BackColor = Color.Transparent
    End Sub

    Private Sub btnFineHistory_Click(sender As Object, e As EventArgs) Handles btnFineHistory.Click
        pnlLeftBorrowedBook.Visible = False
        pnlLeftFineHistory.Visible = True

        panelBorrowedBook.Visible = False
        panelFineHistory.Visible = True

        btnDisplayAll2_Click(sender, e)
    End Sub

    Private Sub btnSearch2_Click(sender As Object, e As EventArgs) Handles btnSearch2.Click
        Dim search As String = "Select * From Fine_Payment Where BookID = @book"
        searchButton(txtSearchBookID2.Text, search, viewFineHistory)
    End Sub

    Private Sub btnDisplayAll2_Click(sender As Object, e As EventArgs) Handles btnDisplayAll2.Click
        Dim command As New SqlCommand("Select * From Fine_Payment", connection)
        connection.Open()
        Dim adapter As New SqlDataAdapter(command)
        Dim table As New DataTable
        adapter.Fill(table)
        viewFineHistory.DataSource = table
        connection.Close()
    End Sub

    Private Sub picBack_Click(sender As Object, e As EventArgs) Handles picBack.Click
        Me.Hide()
        frmStudentAction.Show()
    End Sub
End Class