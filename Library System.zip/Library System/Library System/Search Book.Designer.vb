﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSearchBook
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSearchBook))
        Me.BunifuElipse1 = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.pnlLeftLanguage = New System.Windows.Forms.FlowLayoutPanel()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.btnLanguage = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.picBack = New System.Windows.Forms.PictureBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pnlLeftTitle = New System.Windows.Forms.FlowLayoutPanel()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.btnBookTitle = New System.Windows.Forms.Button()
        Me.pnlLeftID = New System.Windows.Forms.FlowLayoutPanel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnBookID = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.lblClose = New System.Windows.Forms.Label()
        Me.panelLanguage = New System.Windows.Forms.Panel()
        Me.viewBook3 = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.CatagoriesDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LanguageDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CoordinationDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BookDataTableBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.btnDisplayAll3 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.cmbLanguage = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnSearch3 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.panelBookID = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.txtSearchBookID = New System.Windows.Forms.TextBox()
        Me.viewBook1 = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.CatagoriesDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LanguageDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CoordinationDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.btnDisplayAll1 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnSearch1 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.panelBookTitle = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel2 = New System.Windows.Forms.FlowLayoutPanel()
        Me.txtSearchBookTitle = New System.Windows.Forms.TextBox()
        Me.viewBook2 = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.CatagoriesDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LanguageDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CoordinationDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.btnDisplayAll2 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnSearch2 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.Panel4.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBack, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.panelLanguage.SuspendLayout()
        CType(Me.viewBook3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BookDataTableBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelBookID.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        CType(Me.viewBook1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelBookTitle.SuspendLayout()
        Me.FlowLayoutPanel2.SuspendLayout()
        CType(Me.viewBook2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BunifuElipse1
        '
        Me.BunifuElipse1.ElipseRadius = 20
        Me.BunifuElipse1.TargetControl = Me
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(67, Byte), Integer))
        Me.Panel4.Controls.Add(Me.pnlLeftLanguage)
        Me.Panel4.Controls.Add(Me.PictureBox5)
        Me.Panel4.Controls.Add(Me.btnLanguage)
        Me.Panel4.Controls.Add(Me.Label3)
        Me.Panel4.Controls.Add(Me.Label2)
        Me.Panel4.Controls.Add(Me.picBack)
        Me.Panel4.Controls.Add(Me.Panel3)
        Me.Panel4.Controls.Add(Me.Panel1)
        Me.Panel4.Controls.Add(Me.Label1)
        Me.Panel4.Controls.Add(Me.pnlLeftTitle)
        Me.Panel4.Controls.Add(Me.PictureBox4)
        Me.Panel4.Controls.Add(Me.btnBookTitle)
        Me.Panel4.Controls.Add(Me.pnlLeftID)
        Me.Panel4.Controls.Add(Me.PictureBox1)
        Me.Panel4.Controls.Add(Me.btnBookID)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Margin = New System.Windows.Forms.Padding(5)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(239, 500)
        Me.Panel4.TabIndex = 2
        '
        'pnlLeftLanguage
        '
        Me.pnlLeftLanguage.BackColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer))
        Me.pnlLeftLanguage.Location = New System.Drawing.Point(-2, 317)
        Me.pnlLeftLanguage.Name = "pnlLeftLanguage"
        Me.pnlLeftLanguage.Size = New System.Drawing.Size(10, 34)
        Me.pnlLeftLanguage.TabIndex = 23
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), System.Drawing.Image)
        Me.PictureBox5.Location = New System.Drawing.Point(25, 317)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(33, 34)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 22
        Me.PictureBox5.TabStop = False
        '
        'btnLanguage
        '
        Me.btnLanguage.FlatAppearance.BorderSize = 0
        Me.btnLanguage.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLanguage.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLanguage.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btnLanguage.Location = New System.Drawing.Point(-2, 317)
        Me.btnLanguage.Name = "btnLanguage"
        Me.btnLanguage.Size = New System.Drawing.Size(241, 34)
        Me.btnLanguage.TabIndex = 21
        Me.btnLanguage.Text = "   Language"
        Me.btnLanguage.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.Control
        Me.Label3.Location = New System.Drawing.Point(20, 177)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(81, 21)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "Search by:"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 23.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(119, 107)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(94, 39)
        Me.Label2.TabIndex = 19
        Me.Label2.Text = "Book"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'picBack
        '
        Me.picBack.Cursor = System.Windows.Forms.Cursors.Default
        Me.picBack.Image = CType(resources.GetObject("picBack.Image"), System.Drawing.Image)
        Me.picBack.Location = New System.Drawing.Point(2, 3)
        Me.picBack.Name = "picBack"
        Me.picBack.Size = New System.Drawing.Size(33, 34)
        Me.picBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBack.TabIndex = 18
        Me.picBack.TabStop = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.White
        Me.Panel3.Location = New System.Drawing.Point(14, 116)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(44, 8)
        Me.Panel3.TabIndex = 13
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Location = New System.Drawing.Point(32, 98)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(8, 44)
        Me.Panel1.TabIndex = 12
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 23.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(45, 71)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(115, 42)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Search"
        '
        'pnlLeftTitle
        '
        Me.pnlLeftTitle.BackColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer))
        Me.pnlLeftTitle.Location = New System.Drawing.Point(-2, 262)
        Me.pnlLeftTitle.Name = "pnlLeftTitle"
        Me.pnlLeftTitle.Size = New System.Drawing.Size(10, 34)
        Me.pnlLeftTitle.TabIndex = 7
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(24, 262)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(34, 34)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 6
        Me.PictureBox4.TabStop = False
        '
        'btnBookTitle
        '
        Me.btnBookTitle.FlatAppearance.BorderSize = 0
        Me.btnBookTitle.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBookTitle.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBookTitle.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btnBookTitle.Location = New System.Drawing.Point(-2, 262)
        Me.btnBookTitle.Name = "btnBookTitle"
        Me.btnBookTitle.Size = New System.Drawing.Size(241, 34)
        Me.btnBookTitle.TabIndex = 5
        Me.btnBookTitle.Text = "    Book Title"
        Me.btnBookTitle.UseVisualStyleBackColor = True
        '
        'pnlLeftID
        '
        Me.pnlLeftID.BackColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer))
        Me.pnlLeftID.Location = New System.Drawing.Point(-2, 212)
        Me.pnlLeftID.Name = "pnlLeftID"
        Me.pnlLeftID.Size = New System.Drawing.Size(10, 34)
        Me.pnlLeftID.TabIndex = 4
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(24, 212)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(34, 34)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'btnBookID
        '
        Me.btnBookID.FlatAppearance.BorderSize = 0
        Me.btnBookID.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBookID.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBookID.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btnBookID.Location = New System.Drawing.Point(-2, 212)
        Me.btnBookID.Name = "btnBookID"
        Me.btnBookID.Size = New System.Drawing.Size(241, 34)
        Me.btnBookID.TabIndex = 2
        Me.btnBookID.Text = "Book ID"
        Me.btnBookID.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(29, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), System.Drawing.Image)
        Me.Panel2.Controls.Add(Me.lblClose)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(239, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(727, 36)
        Me.Panel2.TabIndex = 25
        '
        'lblClose
        '
        Me.lblClose.BackColor = System.Drawing.Color.Transparent
        Me.lblClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblClose.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClose.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblClose.Location = New System.Drawing.Point(693, -1)
        Me.lblClose.Name = "lblClose"
        Me.lblClose.Size = New System.Drawing.Size(31, 32)
        Me.lblClose.TabIndex = 2
        Me.lblClose.Text = "x"
        Me.lblClose.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'panelLanguage
        '
        Me.panelLanguage.BackgroundImage = CType(resources.GetObject("panelLanguage.BackgroundImage"), System.Drawing.Image)
        Me.panelLanguage.Controls.Add(Me.viewBook3)
        Me.panelLanguage.Controls.Add(Me.btnDisplayAll3)
        Me.panelLanguage.Controls.Add(Me.cmbLanguage)
        Me.panelLanguage.Controls.Add(Me.Label5)
        Me.panelLanguage.Controls.Add(Me.btnSearch3)
        Me.panelLanguage.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.panelLanguage.Location = New System.Drawing.Point(239, 36)
        Me.panelLanguage.Name = "panelLanguage"
        Me.panelLanguage.Size = New System.Drawing.Size(726, 463)
        Me.panelLanguage.TabIndex = 26
        Me.panelLanguage.Visible = False
        '
        'viewBook3
        '
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.viewBook3.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle5
        Me.viewBook3.AutoGenerateColumns = False
        Me.viewBook3.BackgroundColor = System.Drawing.Color.Gainsboro
        Me.viewBook3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.viewBook3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(49, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(57, Byte), Integer))
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(245, Byte), Integer))
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.viewBook3.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.viewBook3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.viewBook3.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CatagoriesDataGridViewTextBoxColumn2, Me.LanguageDataGridViewTextBoxColumn2, Me.CoordinationDataGridViewTextBoxColumn2})
        Me.viewBook3.DataSource = Me.BookDataTableBindingSource
        Me.viewBook3.DoubleBuffered = True
        Me.viewBook3.EnableHeadersVisualStyles = False
        Me.viewBook3.HeaderBgColor = System.Drawing.Color.FromArgb(CType(CType(49, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.viewBook3.HeaderForeColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(245, Byte), Integer))
        Me.viewBook3.Location = New System.Drawing.Point(41, 83)
        Me.viewBook3.Name = "viewBook3"
        Me.viewBook3.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.viewBook3.Size = New System.Drawing.Size(643, 297)
        Me.viewBook3.TabIndex = 29
        '
        'CatagoriesDataGridViewTextBoxColumn2
        '
        Me.CatagoriesDataGridViewTextBoxColumn2.DataPropertyName = "Catagories"
        Me.CatagoriesDataGridViewTextBoxColumn2.HeaderText = "Catagories"
        Me.CatagoriesDataGridViewTextBoxColumn2.Name = "CatagoriesDataGridViewTextBoxColumn2"
        '
        'LanguageDataGridViewTextBoxColumn2
        '
        Me.LanguageDataGridViewTextBoxColumn2.DataPropertyName = "Language"
        Me.LanguageDataGridViewTextBoxColumn2.HeaderText = "Language"
        Me.LanguageDataGridViewTextBoxColumn2.Name = "LanguageDataGridViewTextBoxColumn2"
        '
        'CoordinationDataGridViewTextBoxColumn2
        '
        Me.CoordinationDataGridViewTextBoxColumn2.DataPropertyName = "Coordination"
        Me.CoordinationDataGridViewTextBoxColumn2.HeaderText = "Coordination"
        Me.CoordinationDataGridViewTextBoxColumn2.Name = "CoordinationDataGridViewTextBoxColumn2"
        '
        'BookDataTableBindingSource
        '
        Me.BookDataTableBindingSource.DataSource = GetType(Library_System.TestingDatabase1DataSet.BookDataTable)
        '
        'btnDisplayAll3
        '
        Me.btnDisplayAll3.ActiveBorderThickness = 1
        Me.btnDisplayAll3.ActiveCornerRadius = 20
        Me.btnDisplayAll3.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnDisplayAll3.ActiveForecolor = System.Drawing.Color.White
        Me.btnDisplayAll3.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnDisplayAll3.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnDisplayAll3.BackgroundImage = CType(resources.GetObject("btnDisplayAll3.BackgroundImage"), System.Drawing.Image)
        Me.btnDisplayAll3.ButtonText = "Display All"
        Me.btnDisplayAll3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDisplayAll3.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDisplayAll3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnDisplayAll3.IdleBorderThickness = 1
        Me.btnDisplayAll3.IdleCornerRadius = 20
        Me.btnDisplayAll3.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnDisplayAll3.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.btnDisplayAll3.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnDisplayAll3.Location = New System.Drawing.Point(540, 398)
        Me.btnDisplayAll3.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnDisplayAll3.Name = "btnDisplayAll3"
        Me.btnDisplayAll3.Size = New System.Drawing.Size(122, 44)
        Me.btnDisplayAll3.TabIndex = 28
        Me.btnDisplayAll3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmbLanguage
        '
        Me.cmbLanguage.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.cmbLanguage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbLanguage.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbLanguage.ForeColor = System.Drawing.Color.Black
        Me.cmbLanguage.FormattingEnabled = True
        Me.cmbLanguage.Items.AddRange(New Object() {"English", "Bahasa Malaysia", "Chinese"})
        Me.cmbLanguage.Location = New System.Drawing.Point(136, 23)
        Me.cmbLanguage.Name = "cmbLanguage"
        Me.cmbLanguage.Size = New System.Drawing.Size(215, 31)
        Me.cmbLanguage.TabIndex = 26
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(36, 27)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(101, 23)
        Me.Label5.TabIndex = 20
        Me.Label5.Text = "Language:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnSearch3
        '
        Me.btnSearch3.ActiveBorderThickness = 1
        Me.btnSearch3.ActiveCornerRadius = 20
        Me.btnSearch3.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnSearch3.ActiveForecolor = System.Drawing.Color.White
        Me.btnSearch3.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnSearch3.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnSearch3.BackgroundImage = CType(resources.GetObject("btnSearch3.BackgroundImage"), System.Drawing.Image)
        Me.btnSearch3.ButtonText = "Search"
        Me.btnSearch3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSearch3.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSearch3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSearch3.IdleBorderThickness = 1
        Me.btnSearch3.IdleCornerRadius = 20
        Me.btnSearch3.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSearch3.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.btnSearch3.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSearch3.Location = New System.Drawing.Point(438, 16)
        Me.btnSearch3.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnSearch3.Name = "btnSearch3"
        Me.btnSearch3.Size = New System.Drawing.Size(97, 44)
        Me.btnSearch3.TabIndex = 22
        Me.btnSearch3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'panelBookID
        '
        Me.panelBookID.BackgroundImage = CType(resources.GetObject("panelBookID.BackgroundImage"), System.Drawing.Image)
        Me.panelBookID.Controls.Add(Me.FlowLayoutPanel1)
        Me.panelBookID.Controls.Add(Me.viewBook1)
        Me.panelBookID.Controls.Add(Me.btnDisplayAll1)
        Me.panelBookID.Controls.Add(Me.Label4)
        Me.panelBookID.Controls.Add(Me.btnSearch1)
        Me.panelBookID.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.panelBookID.Location = New System.Drawing.Point(239, 36)
        Me.panelBookID.Name = "panelBookID"
        Me.panelBookID.Size = New System.Drawing.Size(726, 463)
        Me.panelBookID.TabIndex = 30
        Me.panelBookID.Visible = False
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.BackColor = System.Drawing.Color.White
        Me.FlowLayoutPanel1.Controls.Add(Me.txtSearchBookID)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(120, 23)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Padding = New System.Windows.Forms.Padding(1)
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(175, 31)
        Me.FlowLayoutPanel1.TabIndex = 30
        '
        'txtSearchBookID
        '
        Me.txtSearchBookID.BackColor = System.Drawing.SystemColors.Window
        Me.txtSearchBookID.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSearchBookID.Dock = System.Windows.Forms.DockStyle.Top
        Me.txtSearchBookID.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchBookID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSearchBookID.Location = New System.Drawing.Point(4, 4)
        Me.txtSearchBookID.Name = "txtSearchBookID"
        Me.txtSearchBookID.Size = New System.Drawing.Size(167, 23)
        Me.txtSearchBookID.TabIndex = 0
        '
        'viewBook1
        '
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.viewBook1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle3
        Me.viewBook1.AutoGenerateColumns = False
        Me.viewBook1.BackgroundColor = System.Drawing.Color.Gainsboro
        Me.viewBook1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.viewBook1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(49, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(57, Byte), Integer))
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(245, Byte), Integer))
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.viewBook1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.viewBook1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.viewBook1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CatagoriesDataGridViewTextBoxColumn1, Me.LanguageDataGridViewTextBoxColumn1, Me.CoordinationDataGridViewTextBoxColumn1})
        Me.viewBook1.DataSource = Me.BookDataTableBindingSource
        Me.viewBook1.DoubleBuffered = True
        Me.viewBook1.EnableHeadersVisualStyles = False
        Me.viewBook1.HeaderBgColor = System.Drawing.Color.FromArgb(CType(CType(49, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.viewBook1.HeaderForeColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(245, Byte), Integer))
        Me.viewBook1.Location = New System.Drawing.Point(41, 83)
        Me.viewBook1.Name = "viewBook1"
        Me.viewBook1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.viewBook1.Size = New System.Drawing.Size(643, 297)
        Me.viewBook1.TabIndex = 29
        '
        'CatagoriesDataGridViewTextBoxColumn1
        '
        Me.CatagoriesDataGridViewTextBoxColumn1.DataPropertyName = "Catagories"
        Me.CatagoriesDataGridViewTextBoxColumn1.HeaderText = "Catagories"
        Me.CatagoriesDataGridViewTextBoxColumn1.Name = "CatagoriesDataGridViewTextBoxColumn1"
        '
        'LanguageDataGridViewTextBoxColumn1
        '
        Me.LanguageDataGridViewTextBoxColumn1.DataPropertyName = "Language"
        Me.LanguageDataGridViewTextBoxColumn1.HeaderText = "Language"
        Me.LanguageDataGridViewTextBoxColumn1.Name = "LanguageDataGridViewTextBoxColumn1"
        '
        'CoordinationDataGridViewTextBoxColumn1
        '
        Me.CoordinationDataGridViewTextBoxColumn1.DataPropertyName = "Coordination"
        Me.CoordinationDataGridViewTextBoxColumn1.HeaderText = "Coordination"
        Me.CoordinationDataGridViewTextBoxColumn1.Name = "CoordinationDataGridViewTextBoxColumn1"
        '
        'btnDisplayAll1
        '
        Me.btnDisplayAll1.ActiveBorderThickness = 1
        Me.btnDisplayAll1.ActiveCornerRadius = 20
        Me.btnDisplayAll1.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnDisplayAll1.ActiveForecolor = System.Drawing.Color.White
        Me.btnDisplayAll1.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnDisplayAll1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnDisplayAll1.BackgroundImage = CType(resources.GetObject("btnDisplayAll1.BackgroundImage"), System.Drawing.Image)
        Me.btnDisplayAll1.ButtonText = "Display All"
        Me.btnDisplayAll1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDisplayAll1.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDisplayAll1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnDisplayAll1.IdleBorderThickness = 1
        Me.btnDisplayAll1.IdleCornerRadius = 20
        Me.btnDisplayAll1.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnDisplayAll1.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.btnDisplayAll1.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnDisplayAll1.Location = New System.Drawing.Point(540, 398)
        Me.btnDisplayAll1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnDisplayAll1.Name = "btnDisplayAll1"
        Me.btnDisplayAll1.Size = New System.Drawing.Size(122, 44)
        Me.btnDisplayAll1.TabIndex = 28
        Me.btnDisplayAll1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(36, 27)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(101, 23)
        Me.Label4.TabIndex = 20
        Me.Label4.Text = "Book ID:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnSearch1
        '
        Me.btnSearch1.ActiveBorderThickness = 1
        Me.btnSearch1.ActiveCornerRadius = 20
        Me.btnSearch1.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnSearch1.ActiveForecolor = System.Drawing.Color.White
        Me.btnSearch1.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnSearch1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnSearch1.BackgroundImage = CType(resources.GetObject("btnSearch1.BackgroundImage"), System.Drawing.Image)
        Me.btnSearch1.ButtonText = "Search"
        Me.btnSearch1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSearch1.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSearch1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSearch1.IdleBorderThickness = 1
        Me.btnSearch1.IdleCornerRadius = 20
        Me.btnSearch1.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSearch1.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.btnSearch1.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSearch1.Location = New System.Drawing.Point(370, 16)
        Me.btnSearch1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnSearch1.Name = "btnSearch1"
        Me.btnSearch1.Size = New System.Drawing.Size(97, 44)
        Me.btnSearch1.TabIndex = 22
        Me.btnSearch1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'panelBookTitle
        '
        Me.panelBookTitle.Controls.Add(Me.FlowLayoutPanel2)
        Me.panelBookTitle.Controls.Add(Me.viewBook2)
        Me.panelBookTitle.Controls.Add(Me.btnDisplayAll2)
        Me.panelBookTitle.Controls.Add(Me.Label6)
        Me.panelBookTitle.Controls.Add(Me.btnSearch2)
        Me.panelBookTitle.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.panelBookTitle.Location = New System.Drawing.Point(239, 36)
        Me.panelBookTitle.Name = "panelBookTitle"
        Me.panelBookTitle.Size = New System.Drawing.Size(726, 463)
        Me.panelBookTitle.TabIndex = 31
        Me.panelBookTitle.Visible = False
        '
        'FlowLayoutPanel2
        '
        Me.FlowLayoutPanel2.BackColor = System.Drawing.Color.White
        Me.FlowLayoutPanel2.Controls.Add(Me.txtSearchBookTitle)
        Me.FlowLayoutPanel2.Location = New System.Drawing.Point(135, 23)
        Me.FlowLayoutPanel2.Name = "FlowLayoutPanel2"
        Me.FlowLayoutPanel2.Padding = New System.Windows.Forms.Padding(1)
        Me.FlowLayoutPanel2.Size = New System.Drawing.Size(358, 31)
        Me.FlowLayoutPanel2.TabIndex = 30
        '
        'txtSearchBookTitle
        '
        Me.txtSearchBookTitle.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSearchBookTitle.Dock = System.Windows.Forms.DockStyle.Top
        Me.txtSearchBookTitle.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchBookTitle.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSearchBookTitle.Location = New System.Drawing.Point(4, 4)
        Me.txtSearchBookTitle.Name = "txtSearchBookTitle"
        Me.txtSearchBookTitle.Size = New System.Drawing.Size(350, 23)
        Me.txtSearchBookTitle.TabIndex = 0
        '
        'viewBook2
        '
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.viewBook2.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.viewBook2.AutoGenerateColumns = False
        Me.viewBook2.BackgroundColor = System.Drawing.Color.Gainsboro
        Me.viewBook2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.viewBook2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(49, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(57, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(245, Byte), Integer))
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.viewBook2.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.viewBook2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.viewBook2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CatagoriesDataGridViewTextBoxColumn, Me.LanguageDataGridViewTextBoxColumn, Me.CoordinationDataGridViewTextBoxColumn})
        Me.viewBook2.DataSource = Me.BookDataTableBindingSource
        Me.viewBook2.DoubleBuffered = True
        Me.viewBook2.EnableHeadersVisualStyles = False
        Me.viewBook2.HeaderBgColor = System.Drawing.Color.FromArgb(CType(CType(49, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.viewBook2.HeaderForeColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(245, Byte), Integer))
        Me.viewBook2.Location = New System.Drawing.Point(41, 83)
        Me.viewBook2.Name = "viewBook2"
        Me.viewBook2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.viewBook2.Size = New System.Drawing.Size(643, 297)
        Me.viewBook2.TabIndex = 29
        '
        'CatagoriesDataGridViewTextBoxColumn
        '
        Me.CatagoriesDataGridViewTextBoxColumn.DataPropertyName = "Catagories"
        Me.CatagoriesDataGridViewTextBoxColumn.HeaderText = "Catagories"
        Me.CatagoriesDataGridViewTextBoxColumn.Name = "CatagoriesDataGridViewTextBoxColumn"
        '
        'LanguageDataGridViewTextBoxColumn
        '
        Me.LanguageDataGridViewTextBoxColumn.DataPropertyName = "Language"
        Me.LanguageDataGridViewTextBoxColumn.HeaderText = "Language"
        Me.LanguageDataGridViewTextBoxColumn.Name = "LanguageDataGridViewTextBoxColumn"
        '
        'CoordinationDataGridViewTextBoxColumn
        '
        Me.CoordinationDataGridViewTextBoxColumn.DataPropertyName = "Coordination"
        Me.CoordinationDataGridViewTextBoxColumn.HeaderText = "Coordination"
        Me.CoordinationDataGridViewTextBoxColumn.Name = "CoordinationDataGridViewTextBoxColumn"
        '
        'btnDisplayAll2
        '
        Me.btnDisplayAll2.ActiveBorderThickness = 1
        Me.btnDisplayAll2.ActiveCornerRadius = 20
        Me.btnDisplayAll2.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnDisplayAll2.ActiveForecolor = System.Drawing.Color.White
        Me.btnDisplayAll2.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnDisplayAll2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnDisplayAll2.BackgroundImage = CType(resources.GetObject("btnDisplayAll2.BackgroundImage"), System.Drawing.Image)
        Me.btnDisplayAll2.ButtonText = "Display All"
        Me.btnDisplayAll2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDisplayAll2.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDisplayAll2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnDisplayAll2.IdleBorderThickness = 1
        Me.btnDisplayAll2.IdleCornerRadius = 20
        Me.btnDisplayAll2.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnDisplayAll2.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.btnDisplayAll2.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnDisplayAll2.Location = New System.Drawing.Point(540, 398)
        Me.btnDisplayAll2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnDisplayAll2.Name = "btnDisplayAll2"
        Me.btnDisplayAll2.Size = New System.Drawing.Size(122, 44)
        Me.btnDisplayAll2.TabIndex = 28
        Me.btnDisplayAll2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(36, 27)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(101, 23)
        Me.Label6.TabIndex = 20
        Me.Label6.Text = "Book Title:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnSearch2
        '
        Me.btnSearch2.ActiveBorderThickness = 1
        Me.btnSearch2.ActiveCornerRadius = 20
        Me.btnSearch2.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnSearch2.ActiveForecolor = System.Drawing.Color.White
        Me.btnSearch2.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnSearch2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnSearch2.BackgroundImage = CType(resources.GetObject("btnSearch2.BackgroundImage"), System.Drawing.Image)
        Me.btnSearch2.ButtonText = "Search"
        Me.btnSearch2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSearch2.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSearch2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSearch2.IdleBorderThickness = 1
        Me.btnSearch2.IdleCornerRadius = 20
        Me.btnSearch2.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSearch2.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.btnSearch2.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSearch2.Location = New System.Drawing.Point(550, 16)
        Me.btnSearch2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnSearch2.Name = "btnSearch2"
        Me.btnSearch2.Size = New System.Drawing.Size(97, 44)
        Me.btnSearch2.TabIndex = 22
        Me.btnSearch2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmSearchBook
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 23.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(966, 500)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.panelBookTitle)
        Me.Controls.Add(Me.panelBookID)
        Me.Controls.Add(Me.panelLanguage)
        Me.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmSearchBook"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "SearchTest"
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBack, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.panelLanguage.ResumeLayout(False)
        CType(Me.viewBook3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BookDataTableBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelBookID.ResumeLayout(False)
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.FlowLayoutPanel1.PerformLayout()
        CType(Me.viewBook1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelBookTitle.ResumeLayout(False)
        Me.FlowLayoutPanel2.ResumeLayout(False)
        Me.FlowLayoutPanel2.PerformLayout()
        CType(Me.viewBook2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BunifuElipse1 As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents Panel4 As Panel
    Friend WithEvents pnlLeftLanguage As FlowLayoutPanel
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents btnLanguage As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents picBack As PictureBox
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents pnlLeftTitle As FlowLayoutPanel
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents btnBookTitle As Button
    Friend WithEvents pnlLeftID As FlowLayoutPanel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnBookID As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents lblClose As Label
    Friend WithEvents panelLanguage As Panel
    Friend WithEvents btnDisplayAll3 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents cmbLanguage As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents btnSearch3 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents viewBook3 As Bunifu.Framework.UI.BunifuCustomDataGrid
    Friend WithEvents panelBookID As Panel
    Friend WithEvents viewBook1 As Bunifu.Framework.UI.BunifuCustomDataGrid
    Friend WithEvents btnDisplayAll1 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents Label4 As Label
    Friend WithEvents btnSearch1 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents txtSearchBookID As TextBox
    Friend WithEvents panelBookTitle As Panel
    Friend WithEvents FlowLayoutPanel2 As FlowLayoutPanel
    Friend WithEvents txtSearchBookTitle As TextBox
    Friend WithEvents viewBook2 As Bunifu.Framework.UI.BunifuCustomDataGrid
    Friend WithEvents btnDisplayAll2 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents Label6 As Label
    Friend WithEvents btnSearch2 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BookDataTableBindingSource As BindingSource
    Friend WithEvents BookIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BookTitleDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CatagoriesDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents LanguageDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents QuantityAvailableDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CoordinationDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BookIDDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents BookTitleDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents CatagoriesDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents LanguageDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents QuantityAvailableDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents CoordinationDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents BookIDDataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents BookTitleDataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents CatagoriesDataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents LanguageDataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents QuantityAvailableDataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents CoordinationDataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
End Class
