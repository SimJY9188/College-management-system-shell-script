﻿Public Class frmLibrarianAction
    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        End
    End Sub

    Private Sub frmLibrarianAction_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        btnTransaction.BackColor = Color.Transparent
        btnBook.BackColor = Color.Transparent
        btnStudent.BackColor = Color.Transparent
        btnReport.BackColor = Color.Transparent
        btnLogOut.BackColor = Color.Transparent
        btnSwitchIdentity.BackColor = Color.Transparent
    End Sub

    Private Sub btnTransaction_Click(sender As Object, e As EventArgs) Handles btnTransaction.Click
        Me.Hide()
        frmTransaction.Show()
    End Sub

    Private Sub btnSwitchIdentity_Click(sender As Object, e As EventArgs) Handles btnSwitchIdentity.Click
        Me.Hide()
        frmLoginWith.Show()
    End Sub

    Private Sub btnReport_Click(sender As Object, e As EventArgs) Handles btnReport.Click
        Me.Hide()
        frmReports.Show()
    End Sub
End Class