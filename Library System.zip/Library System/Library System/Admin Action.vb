﻿Public Class frmAdminAction
    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        End
    End Sub

    Private Sub frmAdminAction_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        btnTransaction.BackColor = Color.Transparent
        btnBook.BackColor = Color.Transparent
        btnLibrarian.BackColor = Color.Transparent
        btnStudent.BackColor = Color.Transparent
        btnBlackList.BackColor = Color.Transparent
        btnReport.BackColor = Color.Transparent
        btnLogOut.BackColor = Color.Transparent
        btnSwitchIdentity.BackColor = Color.Transparent
    End Sub

    Private Sub btnTransaction_Click(sender As Object, e As EventArgs) Handles btnTransaction.Click
        Me.Hide()
        frmTransaction.Show()
    End Sub

    Private Sub btnBlackList_Click(sender As Object, e As EventArgs) Handles btnBlackList.Click
        Me.Hide()
        frmBlackList.Show()
    End Sub

    Private Sub btnSwitchIdentity_Click(sender As Object, e As EventArgs) Handles btnSwitchIdentity.Click
        Me.Hide()
        frmLoginWith.Show()
    End Sub

    Private Sub btnReport_Click(sender As Object, e As EventArgs) Handles btnReport.Click
        Me.Hide()
        frmReports.Show()
    End Sub
End Class