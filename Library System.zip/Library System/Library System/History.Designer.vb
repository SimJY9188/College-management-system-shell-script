﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHistory
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmHistory))
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.picBack = New System.Windows.Forms.PictureBox()
        Me.panel6 = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pnlLeftFineHistory = New System.Windows.Forms.FlowLayoutPanel()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.btnFineHistory = New System.Windows.Forms.Button()
        Me.pnlLeftBorrowedBook = New System.Windows.Forms.FlowLayoutPanel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnBorrowedBook = New System.Windows.Forms.Button()
        Me.BunifuElipse1 = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.lblClose = New System.Windows.Forms.Label()
        Me.panelBorrowedBook = New System.Windows.Forms.Panel()
        Me.viewBorrowedBook = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.BookIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BookTitleDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.QuantityBorrowDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReturnDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BorrowedBookDataTableBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.btnDisplayAll = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.FlowLayoutPanel9 = New System.Windows.Forms.FlowLayoutPanel()
        Me.txtSearchBookID = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.btnSearch = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.panelFineHistory = New System.Windows.Forms.Panel()
        Me.btnDisplayAll2 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.txtSearchBookID2 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnSearch2 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.viewFineHistory = New Bunifu.Framework.UI.BunifuCustomDataGrid()
        Me.BookIDDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BookTitleDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReturnDateDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReasonDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FineChargedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PayStatusDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FinePaymentDataTableBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.ToolTip2 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Panel4.SuspendLayout()
        CType(Me.picBack, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.panelBorrowedBook.SuspendLayout()
        CType(Me.viewBorrowedBook, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BorrowedBookDataTableBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FlowLayoutPanel9.SuspendLayout()
        Me.panelFineHistory.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        CType(Me.viewFineHistory, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FinePaymentDataTableBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(67, Byte), Integer))
        Me.Panel4.Controls.Add(Me.picBack)
        Me.Panel4.Controls.Add(Me.panel6)
        Me.Panel4.Controls.Add(Me.Panel1)
        Me.Panel4.Controls.Add(Me.Label1)
        Me.Panel4.Controls.Add(Me.pnlLeftFineHistory)
        Me.Panel4.Controls.Add(Me.PictureBox4)
        Me.Panel4.Controls.Add(Me.btnFineHistory)
        Me.Panel4.Controls.Add(Me.pnlLeftBorrowedBook)
        Me.Panel4.Controls.Add(Me.PictureBox1)
        Me.Panel4.Controls.Add(Me.btnBorrowedBook)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Margin = New System.Windows.Forms.Padding(5)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(239, 500)
        Me.Panel4.TabIndex = 1
        '
        'picBack
        '
        Me.picBack.Cursor = System.Windows.Forms.Cursors.Default
        Me.picBack.Image = CType(resources.GetObject("picBack.Image"), System.Drawing.Image)
        Me.picBack.Location = New System.Drawing.Point(2, 3)
        Me.picBack.Name = "picBack"
        Me.picBack.Size = New System.Drawing.Size(33, 34)
        Me.picBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBack.TabIndex = 18
        Me.picBack.TabStop = False
        Me.ToolTip1.SetToolTip(Me.picBack, "Click to go back")
        '
        'panel6
        '
        Me.panel6.BackColor = System.Drawing.Color.White
        Me.panel6.Location = New System.Drawing.Point(25, 116)
        Me.panel6.Name = "panel6"
        Me.panel6.Size = New System.Drawing.Size(44, 8)
        Me.panel6.TabIndex = 13
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Location = New System.Drawing.Point(43, 98)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(8, 44)
        Me.Panel1.TabIndex = 12
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 23.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(53, 71)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(126, 42)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "History"
        '
        'pnlLeftFineHistory
        '
        Me.pnlLeftFineHistory.BackColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer))
        Me.pnlLeftFineHistory.Location = New System.Drawing.Point(-2, 246)
        Me.pnlLeftFineHistory.Name = "pnlLeftFineHistory"
        Me.pnlLeftFineHistory.Size = New System.Drawing.Size(10, 34)
        Me.pnlLeftFineHistory.TabIndex = 7
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(24, 246)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(30, 34)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 6
        Me.PictureBox4.TabStop = False
        '
        'btnFineHistory
        '
        Me.btnFineHistory.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnFineHistory.FlatAppearance.BorderSize = 0
        Me.btnFineHistory.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnFineHistory.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFineHistory.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btnFineHistory.Location = New System.Drawing.Point(-2, 246)
        Me.btnFineHistory.Name = "btnFineHistory"
        Me.btnFineHistory.Size = New System.Drawing.Size(241, 34)
        Me.btnFineHistory.TabIndex = 5
        Me.btnFineHistory.Text = "Fine History"
        Me.btnFineHistory.UseVisualStyleBackColor = True
        '
        'pnlLeftBorrowedBook
        '
        Me.pnlLeftBorrowedBook.BackColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer))
        Me.pnlLeftBorrowedBook.Location = New System.Drawing.Point(-2, 196)
        Me.pnlLeftBorrowedBook.Name = "pnlLeftBorrowedBook"
        Me.pnlLeftBorrowedBook.Size = New System.Drawing.Size(10, 34)
        Me.pnlLeftBorrowedBook.TabIndex = 4
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(24, 196)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(30, 34)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'btnBorrowedBook
        '
        Me.btnBorrowedBook.FlatAppearance.BorderSize = 0
        Me.btnBorrowedBook.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBorrowedBook.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBorrowedBook.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btnBorrowedBook.Location = New System.Drawing.Point(-2, 196)
        Me.btnBorrowedBook.Name = "btnBorrowedBook"
        Me.btnBorrowedBook.Size = New System.Drawing.Size(241, 34)
        Me.btnBorrowedBook.TabIndex = 2
        Me.btnBorrowedBook.Text = "      Borrowed Book"
        Me.btnBorrowedBook.UseVisualStyleBackColor = True
        '
        'BunifuElipse1
        '
        Me.BunifuElipse1.ElipseRadius = 20
        Me.BunifuElipse1.TargetControl = Me
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(29, Byte), Integer), CType(CType(29, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), System.Drawing.Image)
        Me.Panel2.Controls.Add(Me.lblClose)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(239, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(727, 36)
        Me.Panel2.TabIndex = 2
        '
        'lblClose
        '
        Me.lblClose.BackColor = System.Drawing.Color.Transparent
        Me.lblClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblClose.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClose.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblClose.Location = New System.Drawing.Point(693, -1)
        Me.lblClose.Name = "lblClose"
        Me.lblClose.Size = New System.Drawing.Size(31, 32)
        Me.lblClose.TabIndex = 2
        Me.lblClose.Text = "x"
        Me.lblClose.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.ToolTip1.SetToolTip(Me.lblClose, "Click to close")
        '
        'panelBorrowedBook
        '
        Me.panelBorrowedBook.BackgroundImage = CType(resources.GetObject("panelBorrowedBook.BackgroundImage"), System.Drawing.Image)
        Me.panelBorrowedBook.Controls.Add(Me.viewBorrowedBook)
        Me.panelBorrowedBook.Controls.Add(Me.btnDisplayAll)
        Me.panelBorrowedBook.Controls.Add(Me.FlowLayoutPanel9)
        Me.panelBorrowedBook.Controls.Add(Me.Label12)
        Me.panelBorrowedBook.Controls.Add(Me.btnSearch)
        Me.panelBorrowedBook.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.panelBorrowedBook.Location = New System.Drawing.Point(239, 35)
        Me.panelBorrowedBook.Name = "panelBorrowedBook"
        Me.panelBorrowedBook.Size = New System.Drawing.Size(727, 465)
        Me.panelBorrowedBook.TabIndex = 3
        '
        'viewBorrowedBook
        '
        DataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.viewBorrowedBook.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle9
        Me.viewBorrowedBook.AutoGenerateColumns = False
        Me.viewBorrowedBook.BackgroundColor = System.Drawing.Color.Gainsboro
        Me.viewBorrowedBook.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.viewBorrowedBook.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(CType(CType(49, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(57, Byte), Integer))
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(245, Byte), Integer))
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.viewBorrowedBook.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.viewBorrowedBook.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.viewBorrowedBook.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.BookIDDataGridViewTextBoxColumn, Me.BookTitleDataGridViewTextBoxColumn, Me.QuantityBorrowDataGridViewTextBoxColumn, Me.ReturnDateDataGridViewTextBoxColumn})
        Me.viewBorrowedBook.DataSource = Me.BorrowedBookDataTableBindingSource
        Me.viewBorrowedBook.DoubleBuffered = True
        Me.viewBorrowedBook.EnableHeadersVisualStyles = False
        Me.viewBorrowedBook.HeaderBgColor = System.Drawing.Color.FromArgb(CType(CType(49, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.viewBorrowedBook.HeaderForeColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(245, Byte), Integer))
        Me.viewBorrowedBook.Location = New System.Drawing.Point(44, 83)
        Me.viewBorrowedBook.Name = "viewBorrowedBook"
        Me.viewBorrowedBook.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.viewBorrowedBook.Size = New System.Drawing.Size(643, 296)
        Me.viewBorrowedBook.TabIndex = 28
        '
        'BookIDDataGridViewTextBoxColumn
        '
        Me.BookIDDataGridViewTextBoxColumn.DataPropertyName = "BookID"
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BookIDDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle11
        Me.BookIDDataGridViewTextBoxColumn.HeaderText = "Book_ID"
        Me.BookIDDataGridViewTextBoxColumn.Name = "BookIDDataGridViewTextBoxColumn"
        Me.BookIDDataGridViewTextBoxColumn.ReadOnly = True
        Me.BookIDDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.BookIDDataGridViewTextBoxColumn.Width = 75
        '
        'BookTitleDataGridViewTextBoxColumn
        '
        Me.BookTitleDataGridViewTextBoxColumn.DataPropertyName = "BookTitle"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BookTitleDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle12
        Me.BookTitleDataGridViewTextBoxColumn.HeaderText = "                    Book_Title"
        Me.BookTitleDataGridViewTextBoxColumn.Name = "BookTitleDataGridViewTextBoxColumn"
        Me.BookTitleDataGridViewTextBoxColumn.ReadOnly = True
        Me.BookTitleDataGridViewTextBoxColumn.Width = 275
        '
        'QuantityBorrowDataGridViewTextBoxColumn
        '
        Me.QuantityBorrowDataGridViewTextBoxColumn.DataPropertyName = "QuantityBorrow"
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.QuantityBorrowDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle13
        Me.QuantityBorrowDataGridViewTextBoxColumn.HeaderText = "Quantity_Borrow"
        Me.QuantityBorrowDataGridViewTextBoxColumn.Name = "QuantityBorrowDataGridViewTextBoxColumn"
        Me.QuantityBorrowDataGridViewTextBoxColumn.ReadOnly = True
        Me.QuantityBorrowDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.QuantityBorrowDataGridViewTextBoxColumn.Width = 140
        '
        'ReturnDateDataGridViewTextBoxColumn
        '
        Me.ReturnDateDataGridViewTextBoxColumn.DataPropertyName = "ReturnDate"
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ReturnDateDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle14
        Me.ReturnDateDataGridViewTextBoxColumn.HeaderText = "Return_Date"
        Me.ReturnDateDataGridViewTextBoxColumn.Name = "ReturnDateDataGridViewTextBoxColumn"
        Me.ReturnDateDataGridViewTextBoxColumn.ReadOnly = True
        Me.ReturnDateDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.ReturnDateDataGridViewTextBoxColumn.Width = 108
        '
        'BorrowedBookDataTableBindingSource
        '
        Me.BorrowedBookDataTableBindingSource.DataSource = GetType(Library_System.TestingDatabase1DataSet.Borrowed_BookDataTable)
        '
        'btnDisplayAll
        '
        Me.btnDisplayAll.ActiveBorderThickness = 1
        Me.btnDisplayAll.ActiveCornerRadius = 20
        Me.btnDisplayAll.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnDisplayAll.ActiveForecolor = System.Drawing.Color.White
        Me.btnDisplayAll.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnDisplayAll.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnDisplayAll.BackgroundImage = CType(resources.GetObject("btnDisplayAll.BackgroundImage"), System.Drawing.Image)
        Me.btnDisplayAll.ButtonText = "Display All"
        Me.btnDisplayAll.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDisplayAll.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDisplayAll.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnDisplayAll.IdleBorderThickness = 1
        Me.btnDisplayAll.IdleCornerRadius = 20
        Me.btnDisplayAll.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnDisplayAll.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.btnDisplayAll.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnDisplayAll.Location = New System.Drawing.Point(565, 399)
        Me.btnDisplayAll.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnDisplayAll.Name = "btnDisplayAll"
        Me.btnDisplayAll.Size = New System.Drawing.Size(122, 44)
        Me.btnDisplayAll.TabIndex = 27
        Me.btnDisplayAll.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlowLayoutPanel9
        '
        Me.FlowLayoutPanel9.BackColor = System.Drawing.Color.White
        Me.FlowLayoutPanel9.Controls.Add(Me.txtSearchBookID)
        Me.FlowLayoutPanel9.Location = New System.Drawing.Point(124, 27)
        Me.FlowLayoutPanel9.Name = "FlowLayoutPanel9"
        Me.FlowLayoutPanel9.Padding = New System.Windows.Forms.Padding(1)
        Me.FlowLayoutPanel9.Size = New System.Drawing.Size(167, 31)
        Me.FlowLayoutPanel9.TabIndex = 24
        '
        'txtSearchBookID
        '
        Me.txtSearchBookID.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSearchBookID.Dock = System.Windows.Forms.DockStyle.Top
        Me.txtSearchBookID.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchBookID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSearchBookID.Location = New System.Drawing.Point(4, 4)
        Me.txtSearchBookID.Name = "txtSearchBookID"
        Me.txtSearchBookID.Size = New System.Drawing.Size(159, 23)
        Me.txtSearchBookID.TabIndex = 0
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(40, 31)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(78, 23)
        Me.Label12.TabIndex = 23
        Me.Label12.Text = "Book ID:"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnSearch
        '
        Me.btnSearch.ActiveBorderThickness = 1
        Me.btnSearch.ActiveCornerRadius = 20
        Me.btnSearch.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnSearch.ActiveForecolor = System.Drawing.Color.White
        Me.btnSearch.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnSearch.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnSearch.BackgroundImage = CType(resources.GetObject("btnSearch.BackgroundImage"), System.Drawing.Image)
        Me.btnSearch.ButtonText = "Search"
        Me.btnSearch.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSearch.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSearch.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSearch.IdleBorderThickness = 1
        Me.btnSearch.IdleCornerRadius = 20
        Me.btnSearch.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSearch.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.btnSearch.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSearch.Location = New System.Drawing.Point(366, 20)
        Me.btnSearch.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(97, 44)
        Me.btnSearch.TabIndex = 25
        Me.btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'panelFineHistory
        '
        Me.panelFineHistory.BackgroundImage = CType(resources.GetObject("panelFineHistory.BackgroundImage"), System.Drawing.Image)
        Me.panelFineHistory.Controls.Add(Me.btnDisplayAll2)
        Me.panelFineHistory.Controls.Add(Me.FlowLayoutPanel1)
        Me.panelFineHistory.Controls.Add(Me.Label2)
        Me.panelFineHistory.Controls.Add(Me.btnSearch2)
        Me.panelFineHistory.Controls.Add(Me.viewFineHistory)
        Me.panelFineHistory.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.panelFineHistory.Location = New System.Drawing.Point(239, 35)
        Me.panelFineHistory.Name = "panelFineHistory"
        Me.panelFineHistory.Size = New System.Drawing.Size(727, 465)
        Me.panelFineHistory.TabIndex = 29
        '
        'btnDisplayAll2
        '
        Me.btnDisplayAll2.ActiveBorderThickness = 1
        Me.btnDisplayAll2.ActiveCornerRadius = 20
        Me.btnDisplayAll2.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnDisplayAll2.ActiveForecolor = System.Drawing.Color.White
        Me.btnDisplayAll2.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnDisplayAll2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnDisplayAll2.BackgroundImage = CType(resources.GetObject("btnDisplayAll2.BackgroundImage"), System.Drawing.Image)
        Me.btnDisplayAll2.ButtonText = "Display All"
        Me.btnDisplayAll2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDisplayAll2.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDisplayAll2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnDisplayAll2.IdleBorderThickness = 1
        Me.btnDisplayAll2.IdleCornerRadius = 20
        Me.btnDisplayAll2.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnDisplayAll2.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.btnDisplayAll2.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnDisplayAll2.Location = New System.Drawing.Point(565, 399)
        Me.btnDisplayAll2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnDisplayAll2.Name = "btnDisplayAll2"
        Me.btnDisplayAll2.Size = New System.Drawing.Size(122, 44)
        Me.btnDisplayAll2.TabIndex = 29
        Me.btnDisplayAll2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.BackColor = System.Drawing.Color.White
        Me.FlowLayoutPanel1.Controls.Add(Me.txtSearchBookID2)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(124, 27)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Padding = New System.Windows.Forms.Padding(1)
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(167, 31)
        Me.FlowLayoutPanel1.TabIndex = 24
        '
        'txtSearchBookID2
        '
        Me.txtSearchBookID2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtSearchBookID2.Dock = System.Windows.Forms.DockStyle.Top
        Me.txtSearchBookID2.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchBookID2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSearchBookID2.Location = New System.Drawing.Point(4, 4)
        Me.txtSearchBookID2.Name = "txtSearchBookID2"
        Me.txtSearchBookID2.Size = New System.Drawing.Size(159, 23)
        Me.txtSearchBookID2.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(40, 31)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(78, 23)
        Me.Label2.TabIndex = 23
        Me.Label2.Text = "Book ID:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnSearch2
        '
        Me.btnSearch2.ActiveBorderThickness = 1
        Me.btnSearch2.ActiveCornerRadius = 20
        Me.btnSearch2.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnSearch2.ActiveForecolor = System.Drawing.Color.White
        Me.btnSearch2.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(107, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.btnSearch2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btnSearch2.BackgroundImage = CType(resources.GetObject("btnSearch2.BackgroundImage"), System.Drawing.Image)
        Me.btnSearch2.ButtonText = "Search"
        Me.btnSearch2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSearch2.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSearch2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSearch2.IdleBorderThickness = 1
        Me.btnSearch2.IdleCornerRadius = 20
        Me.btnSearch2.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSearch2.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(249, Byte), Integer))
        Me.btnSearch2.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.btnSearch2.Location = New System.Drawing.Point(366, 20)
        Me.btnSearch2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnSearch2.Name = "btnSearch2"
        Me.btnSearch2.Size = New System.Drawing.Size(97, 44)
        Me.btnSearch2.TabIndex = 25
        Me.btnSearch2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'viewFineHistory
        '
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.viewFineHistory.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.viewFineHistory.AutoGenerateColumns = False
        Me.viewFineHistory.BackgroundColor = System.Drawing.Color.Gainsboro
        Me.viewFineHistory.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.viewFineHistory.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(49, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(57, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(245, Byte), Integer))
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.viewFineHistory.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.viewFineHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.viewFineHistory.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.BookIDDataGridViewTextBoxColumn1, Me.BookTitleDataGridViewTextBoxColumn1, Me.ReturnDateDataGridViewTextBoxColumn1, Me.ReasonDataGridViewTextBoxColumn, Me.FineChargedDataGridViewTextBoxColumn, Me.PayStatusDataGridViewTextBoxColumn})
        Me.viewFineHistory.DataSource = Me.FinePaymentDataTableBindingSource
        Me.viewFineHistory.DoubleBuffered = True
        Me.viewFineHistory.EnableHeadersVisualStyles = False
        Me.viewFineHistory.HeaderBgColor = System.Drawing.Color.FromArgb(CType(CType(49, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.viewFineHistory.HeaderForeColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(245, Byte), Integer))
        Me.viewFineHistory.Location = New System.Drawing.Point(44, 83)
        Me.viewFineHistory.Name = "viewFineHistory"
        Me.viewFineHistory.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.viewFineHistory.Size = New System.Drawing.Size(643, 296)
        Me.viewFineHistory.TabIndex = 0
        '
        'BookIDDataGridViewTextBoxColumn1
        '
        Me.BookIDDataGridViewTextBoxColumn1.DataPropertyName = "BookID"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BookIDDataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle3
        Me.BookIDDataGridViewTextBoxColumn1.HeaderText = "Book_ID"
        Me.BookIDDataGridViewTextBoxColumn1.Name = "BookIDDataGridViewTextBoxColumn1"
        Me.BookIDDataGridViewTextBoxColumn1.ReadOnly = True
        Me.BookIDDataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.BookIDDataGridViewTextBoxColumn1.Width = 75
        '
        'BookTitleDataGridViewTextBoxColumn1
        '
        Me.BookTitleDataGridViewTextBoxColumn1.DataPropertyName = "BookTitle"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BookTitleDataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle4
        Me.BookTitleDataGridViewTextBoxColumn1.HeaderText = "           Book_Title"
        Me.BookTitleDataGridViewTextBoxColumn1.Name = "BookTitleDataGridViewTextBoxColumn1"
        Me.BookTitleDataGridViewTextBoxColumn1.ReadOnly = True
        Me.BookTitleDataGridViewTextBoxColumn1.Width = 200
        '
        'ReturnDateDataGridViewTextBoxColumn1
        '
        Me.ReturnDateDataGridViewTextBoxColumn1.DataPropertyName = "ReturnDate"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ReturnDateDataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle5
        Me.ReturnDateDataGridViewTextBoxColumn1.HeaderText = "Return_Date"
        Me.ReturnDateDataGridViewTextBoxColumn1.Name = "ReturnDateDataGridViewTextBoxColumn1"
        Me.ReturnDateDataGridViewTextBoxColumn1.ReadOnly = True
        Me.ReturnDateDataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.ReturnDateDataGridViewTextBoxColumn1.Width = 107
        '
        'ReasonDataGridViewTextBoxColumn
        '
        Me.ReasonDataGridViewTextBoxColumn.DataPropertyName = "Reason"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ReasonDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle6
        Me.ReasonDataGridViewTextBoxColumn.HeaderText = "Reason"
        Me.ReasonDataGridViewTextBoxColumn.Name = "ReasonDataGridViewTextBoxColumn"
        Me.ReasonDataGridViewTextBoxColumn.ReadOnly = True
        Me.ReasonDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.ReasonDataGridViewTextBoxColumn.Width = 76
        '
        'FineChargedDataGridViewTextBoxColumn
        '
        Me.FineChargedDataGridViewTextBoxColumn.DataPropertyName = "FineCharged"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.FineChargedDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle7
        Me.FineChargedDataGridViewTextBoxColumn.HeaderText = "Fine_Charged"
        Me.FineChargedDataGridViewTextBoxColumn.Name = "FineChargedDataGridViewTextBoxColumn"
        Me.FineChargedDataGridViewTextBoxColumn.ReadOnly = True
        Me.FineChargedDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.FineChargedDataGridViewTextBoxColumn.Width = 115
        '
        'PayStatusDataGridViewTextBoxColumn
        '
        Me.PayStatusDataGridViewTextBoxColumn.DataPropertyName = "PayStatus"
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.PayStatusDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle8
        Me.PayStatusDataGridViewTextBoxColumn.HeaderText = "Pay_Status"
        Me.PayStatusDataGridViewTextBoxColumn.Name = "PayStatusDataGridViewTextBoxColumn"
        Me.PayStatusDataGridViewTextBoxColumn.ReadOnly = True
        Me.PayStatusDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.PayStatusDataGridViewTextBoxColumn.Width = 90
        '
        'FinePaymentDataTableBindingSource
        '
        Me.FinePaymentDataTableBindingSource.DataSource = GetType(Library_System.TestingDatabase1DataSet.Fine_PaymentDataTable)
        '
        'ToolTip1
        '
        '
        'frmHistory
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(966, 500)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.panelFineHistory)
        Me.Controls.Add(Me.panelBorrowedBook)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmHistory"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "History"
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        CType(Me.picBack, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.panelBorrowedBook.ResumeLayout(False)
        CType(Me.viewBorrowedBook, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BorrowedBookDataTableBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FlowLayoutPanel9.ResumeLayout(False)
        Me.FlowLayoutPanel9.PerformLayout()
        Me.panelFineHistory.ResumeLayout(False)
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.FlowLayoutPanel1.PerformLayout()
        CType(Me.viewFineHistory, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FinePaymentDataTableBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel4 As Panel
    Friend WithEvents picBack As PictureBox
    Friend WithEvents panel6 As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents pnlLeftFineHistory As FlowLayoutPanel
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents btnFineHistory As Button
    Friend WithEvents pnlLeftBorrowedBook As FlowLayoutPanel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnBorrowedBook As Button
    Friend WithEvents BunifuElipse1 As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents Panel2 As Panel
    Friend WithEvents lblClose As Label
    Friend WithEvents panelBorrowedBook As Panel
    Friend WithEvents FlowLayoutPanel9 As FlowLayoutPanel
    Friend WithEvents txtSearchBookID As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents btnSearch As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents viewBorrowedBook As Bunifu.Framework.UI.BunifuCustomDataGrid
    Friend WithEvents btnDisplayAll As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BorrowedBookDataTableBindingSource As BindingSource
    Friend WithEvents BookIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BookTitleDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents QuantityBorrowDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ReturnDateDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents panelFineHistory As Panel
    Friend WithEvents viewFineHistory As Bunifu.Framework.UI.BunifuCustomDataGrid
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents txtSearchBookID2 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents btnSearch2 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents btnDisplayAll2 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents FinePaymentDataTableBindingSource As BindingSource
    Friend WithEvents BookIDDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents BookTitleDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents ReturnDateDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents ReasonDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents FineChargedDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PayStatusDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents ToolTip2 As ToolTip
End Class
