﻿Public Class frmStudentAction
    Private Sub frmStudentAction_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        btnSearchBook.BackColor = Color.Transparent
        btnHistory.BackColor = Color.Transparent
        btnLogOut.BackColor = Color.Transparent
        btnSwitchIdentity.BackColor = Color.Transparent
    End Sub

    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        End
    End Sub

    Private Sub btnSearchBook_Click(sender As Object, e As EventArgs) Handles btnSearchBook.Click
        Me.Hide()
        frmSearchBook.Show()
    End Sub

    Private Sub btnHistory_Click(sender As Object, e As EventArgs) Handles btnHistory.Click
        Me.Hide()
        frmHistory.Show()
    End Sub

    Private Sub btnSwitchIdentity_Click(sender As Object, e As EventArgs) Handles btnSwitchIdentity.Click
        Me.Hide()
        frmLoginWith.Show()
    End Sub
End Class